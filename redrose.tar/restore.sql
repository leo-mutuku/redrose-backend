--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 15.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE red_rose;
--
-- Name: red_rose; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE red_rose WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Kenya.1252';


ALTER DATABASE red_rose OWNER TO postgres;

\connect red_rose

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: custom_id_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_id_sequence OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_id bigint NOT NULL,
    role_name character varying(255) NOT NULL,
    role_code integer NOT NULL,
    role_description text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255)
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255),
    ttl numeric(10,2) DEFAULT 120,
    phone character varying(200),
    user_id bigint NOT NULL,
    first_name character varying(200) NOT NULL,
    last_name character varying(200) NOT NULL,
    is_active boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: vendor_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor_entries (
    vendor_entry_id bigint NOT NULL,
    vendor_id bigint NOT NULL,
    description text NOT NULL,
    credited numeric(15,2) NOT NULL,
    debited numeric(15,2) NOT NULL,
    balance numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255)
);


ALTER TABLE public.vendor_entries OWNER TO postgres;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors (
    vendor_id bigint NOT NULL,
    vendor_name character varying(255) NOT NULL,
    vendor_phone character varying(255) NOT NULL,
    vendor_email character varying(255),
    vendor_balance numeric(15,2) DEFAULT 0.00,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean NOT NULL,
    created_by character varying(255)
);


ALTER TABLE public.vendors OWNER TO postgres;

--
-- Name: waitstaff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.waitstaff_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.waitstaff_id_seq OWNER TO postgres;

--
-- Name: waitstaff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waitstaff (
    waitstaff_id bigint DEFAULT nextval('public.waitstaff_id_seq'::regclass) NOT NULL,
    waitstaff_name character varying(255) NOT NULL,
    waitstaff_phone character varying(255) NOT NULL,
    waitstaff_national_id character varying(255) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    pin integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean NOT NULL,
    created_by character varying(255),
    CONSTRAINT waitstaff_pin_check CHECK (((pin >= 100) AND (pin <= 999)))
);


ALTER TABLE public.waitstaff OWNER TO postgres;

--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_id, role_name, role_code, role_description, created_at, created_by) FROM stdin;
\.
COPY public.roles (role_id, role_name, role_code, role_description, created_at, created_by) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, password, created_at, created_by, ttl, phone, user_id, first_name, last_name, is_active) FROM stdin;
\.
COPY public.users (username, password, created_at, created_by, ttl, phone, user_id, first_name, last_name, is_active) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: vendor_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor_entries (vendor_entry_id, vendor_id, description, credited, debited, balance, created_at, created_by) FROM stdin;
\.
COPY public.vendor_entries (vendor_entry_id, vendor_id, description, credited, debited, balance, created_at, created_by) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors (vendor_id, vendor_name, vendor_phone, vendor_email, vendor_balance, created_at, is_active, created_by) FROM stdin;
\.
COPY public.vendors (vendor_id, vendor_name, vendor_phone, vendor_email, vendor_balance, created_at, is_active, created_by) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: waitstaff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waitstaff (waitstaff_id, waitstaff_name, waitstaff_phone, waitstaff_national_id, balance, pin, created_at, is_active, created_by) FROM stdin;
\.
COPY public.waitstaff (waitstaff_id, waitstaff_name, waitstaff_phone, waitstaff_national_id, balance, pin, created_at, is_active, created_by) FROM '$$PATH$$/3379.dat';

--
-- Name: custom_id_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_id_sequence', 2, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 3, true);


--
-- Name: waitstaff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.waitstaff_id_seq', 100, false);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: roles roles_role_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_code_key UNIQUE (role_code);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: vendor_entries vendor_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor_entries
    ADD CONSTRAINT vendor_entries_pkey PRIMARY KEY (vendor_entry_id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (vendor_id);


--
-- Name: vendors vendors_vendor_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_vendor_phone_key UNIQUE (vendor_phone);


--
-- Name: waitstaff waitstaff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_pkey PRIMARY KEY (waitstaff_id);


--
-- Name: waitstaff waitstaff_waitstaff_national_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_waitstaff_national_id_key UNIQUE (waitstaff_national_id);


--
-- Name: waitstaff waitstaff_waitstaff_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_waitstaff_phone_key UNIQUE (waitstaff_phone);


--
-- PostgreSQL database dump complete
--

