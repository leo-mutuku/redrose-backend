--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 15.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE red_rose;
--
-- Name: red_rose; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE red_rose WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Kenya.1252';


ALTER DATABASE red_rose OWNER TO postgres;

\connect red_rose

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: insert_item_tracking(integer, numeric, numeric, numeric, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_item_tracking(p_item_id integer, p_initial_balance numeric, p_current_balance numeric, p_net_change numeric, p_reason character varying, p_action_by integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO item_tracking (
        item_id, initial_balance, current_balance, net_change, reason, action_by, created_at
    )
    VALUES (
        p_item_id, p_initial_balance, p_current_balance, p_net_change, p_reason, p_action_by, NOW()
    );
END;
$$;


ALTER FUNCTION public.insert_item_tracking(p_item_id integer, p_initial_balance numeric, p_current_balance numeric, p_net_change numeric, p_reason character varying, p_action_by integer) OWNER TO postgres;

--
-- Name: update_menu_availability(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_menu_availability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Automatically set 'available' based on the value of 'quantity'
    IF NEW.quantity > 0 THEN
        NEW.available := true;
    ELSE
        NEW.available := false;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_menu_availability() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    account_id bigint NOT NULL,
    account_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone,
    gl_account_id integer
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_account_id_seq OWNER TO postgres;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_account_id_seq OWNED BY public.accounts.account_id;


--
-- Name: banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banks (
    bank_id bigint NOT NULL,
    bank_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone,
    bank_number character varying(255) DEFAULT 0 NOT NULL
);


ALTER TABLE public.banks OWNER TO postgres;

--
-- Name: banks_bank_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banks_bank_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banks_bank_id_seq OWNER TO postgres;

--
-- Name: banks_bank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banks_bank_id_seq OWNED BY public.banks.bank_id;


--
-- Name: cash_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cash_accounts (
    cash_account_id bigint NOT NULL,
    cash_account_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone
);


ALTER TABLE public.cash_accounts OWNER TO postgres;

--
-- Name: cash_accounts_cash_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cash_accounts_cash_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cash_accounts_cash_account_id_seq OWNER TO postgres;

--
-- Name: cash_accounts_cash_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cash_accounts_cash_account_id_seq OWNED BY public.cash_accounts.cash_account_id;


--
-- Name: custom_id_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_id_sequence OWNER TO postgres;

--
-- Name: food_processing_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_processing_header (
    food_processing_header_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    shift_id integer NOT NULL,
    created_by integer
);


ALTER TABLE public.food_processing_header OWNER TO postgres;

--
-- Name: food_processing_header_food_processing_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.food_processing_header_food_processing_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.food_processing_header_food_processing_header_id_seq OWNER TO postgres;

--
-- Name: food_processing_header_food_processing_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.food_processing_header_food_processing_header_id_seq OWNED BY public.food_processing_header.food_processing_header_id;


--
-- Name: food_processing_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_processing_line (
    food_processing_line_id bigint NOT NULL,
    food_processing_header_id integer NOT NULL,
    name character varying(255) NOT NULL,
    station_id integer NOT NULL,
    kitchen_setup_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL
);


ALTER TABLE public.food_processing_line OWNER TO postgres;

--
-- Name: food_processing_line_food_processing_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.food_processing_line_food_processing_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.food_processing_line_food_processing_line_id_seq OWNER TO postgres;

--
-- Name: food_processing_line_food_processing_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.food_processing_line_food_processing_line_id_seq OWNED BY public.food_processing_line.food_processing_line_id;


--
-- Name: fund_transfer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fund_transfer (
    fund_transfer_id bigint NOT NULL,
    src_account_name character varying(200) NOT NULL,
    des_account_name character varying(200) NOT NULL,
    src_account_balance numeric(15,2) DEFAULT 0,
    des_account_balance numeric(15,2) DEFAULT 0,
    amount numeric(15,2) DEFAULT 0,
    created_at timestamp with time zone,
    src_accound_id integer NOT NULL,
    des_accound_id integer NOT NULL
);


ALTER TABLE public.fund_transfer OWNER TO postgres;

--
-- Name: fund_transfer_fund_transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fund_transfer_fund_transfer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fund_transfer_fund_transfer_id_seq OWNER TO postgres;

--
-- Name: fund_transfer_fund_transfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fund_transfer_fund_transfer_id_seq OWNED BY public.fund_transfer.fund_transfer_id;


--
-- Name: gl_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_accounts (
    gl_account_id bigint NOT NULL,
    gl_account_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone
);


ALTER TABLE public.gl_accounts OWNER TO postgres;

--
-- Name: gl_accounts_gl_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gl_accounts_gl_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gl_accounts_gl_account_id_seq OWNER TO postgres;

--
-- Name: gl_accounts_gl_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gl_accounts_gl_account_id_seq OWNED BY public.gl_accounts.gl_account_id;


--
-- Name: item_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_category (
    category_id bigint NOT NULL,
    category_name character varying(255) NOT NULL,
    category_description text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.item_category OWNER TO postgres;

--
-- Name: item_category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_category_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_category_category_id_seq OWNER TO postgres;

--
-- Name: item_category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_category_category_id_seq OWNED BY public.item_category.category_id;


--
-- Name: item_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_register (
    item_id bigint NOT NULL,
    item_name character varying(255) NOT NULL,
    item_description text NOT NULL,
    item_status boolean DEFAULT true NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.item_register OWNER TO postgres;

--
-- Name: item_register_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_register_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_register_item_id_seq OWNER TO postgres;

--
-- Name: item_register_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_register_item_id_seq OWNED BY public.item_register.item_id;


--
-- Name: item_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_tracking (
    item_tracking_id bigint NOT NULL,
    item_id integer NOT NULL,
    initial_balance numeric(15,2) DEFAULT 0.00 NOT NULL,
    current_balance numeric(15,2) DEFAULT 0.00 NOT NULL,
    net_change numeric(15,2) DEFAULT 0.00 NOT NULL,
    reason character varying(255) NOT NULL,
    action_by integer NOT NULL
);


ALTER TABLE public.item_tracking OWNER TO postgres;

--
-- Name: item_tracking_item_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_tracking_item_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_tracking_item_tracking_id_seq OWNER TO postgres;

--
-- Name: item_tracking_item_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_tracking_item_tracking_id_seq OWNED BY public.item_tracking.item_tracking_id;


--
-- Name: item_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_unit (
    unit_id bigint NOT NULL,
    standard_unit_name character varying(255) NOT NULL,
    standard_unit_value numeric(15,2) DEFAULT 0.00 NOT NULL,
    other_unit_name character varying(255) DEFAULT NULL::character varying,
    other_unit_value numeric(15,2) DEFAULT 0.00,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.item_unit OWNER TO postgres;

--
-- Name: item_unit_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_unit_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_unit_unit_id_seq OWNER TO postgres;

--
-- Name: item_unit_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_unit_unit_id_seq OWNED BY public.item_unit.unit_id;


--
-- Name: kitchen_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_ingredients (
    ingredient_id bigint NOT NULL,
    ingredients_id integer NOT NULL,
    quantity numeric(15,2) NOT NULL,
    store_item_id integer NOT NULL
);


ALTER TABLE public.kitchen_ingredients OWNER TO postgres;

--
-- Name: kitchen_ingredients_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitchen_ingredients_ingredient_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitchen_ingredients_ingredient_id_seq OWNER TO postgres;

--
-- Name: kitchen_ingredients_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitchen_ingredients_ingredient_id_seq OWNED BY public.kitchen_ingredients.ingredient_id;


--
-- Name: kitchen_setup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_setup (
    kitchen_setup_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    station_id integer NOT NULL,
    created_at timestamp with time zone,
    menu_item_id integer NOT NULL
);


ALTER TABLE public.kitchen_setup OWNER TO postgres;

--
-- Name: kitchen_setup_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_setup_header (
    kitchen_setup_header_id bigint NOT NULL,
    menu_register_id integer NOT NULL,
    quanity numeric(25,2) DEFAULT 0.00 NOT NULL,
    menu_unit_id integer
);


ALTER TABLE public.kitchen_setup_header OWNER TO postgres;

--
-- Name: kitchen_setup_header_kitchen_setup_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitchen_setup_header_kitchen_setup_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitchen_setup_header_kitchen_setup_header_id_seq OWNER TO postgres;

--
-- Name: kitchen_setup_header_kitchen_setup_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitchen_setup_header_kitchen_setup_header_id_seq OWNED BY public.kitchen_setup_header.kitchen_setup_header_id;


--
-- Name: kitchen_setup_kitchen_setup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitchen_setup_kitchen_setup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitchen_setup_kitchen_setup_id_seq OWNER TO postgres;

--
-- Name: kitchen_setup_kitchen_setup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitchen_setup_kitchen_setup_id_seq OWNED BY public.kitchen_setup.kitchen_setup_id;


--
-- Name: menu_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_category (
    menu_category_id bigint NOT NULL,
    description text NOT NULL,
    category_name character varying(200) NOT NULL,
    category_abbr character varying(200),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.menu_category OWNER TO postgres;

--
-- Name: menu_category_menu_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_category_menu_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_category_menu_category_id_seq OWNER TO postgres;

--
-- Name: menu_category_menu_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_category_menu_category_id_seq OWNED BY public.menu_category.menu_category_id;


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_item (
    menu_item_id bigint NOT NULL,
    menu_register_id integer NOT NULL,
    quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    price numeric(15,2) DEFAULT 0.00 NOT NULL,
    menu_category_id integer NOT NULL,
    available boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.menu_item OWNER TO postgres;

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_item_menu_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_item_menu_item_id_seq OWNER TO postgres;

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNED BY public.menu_item.menu_item_id;


--
-- Name: menu_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_register (
    menu_register_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL
);


ALTER TABLE public.menu_register OWNER TO postgres;

--
-- Name: menu_register_menu_register_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_register_menu_register_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_register_menu_register_id_seq OWNER TO postgres;

--
-- Name: menu_register_menu_register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_register_menu_register_id_seq OWNED BY public.menu_register.menu_register_id;


--
-- Name: menu_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_unit (
    menu_unit_id bigint NOT NULL,
    unit_name character varying(255) NOT NULL,
    unit_abbr character varying(255) NOT NULL,
    value numeric(15,2) NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.menu_unit OWNER TO postgres;

--
-- Name: menu_unit_menu_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_unit_menu_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_unit_menu_unit_id_seq OWNER TO postgres;

--
-- Name: menu_unit_menu_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_unit_menu_unit_id_seq OWNED BY public.menu_unit.menu_unit_id;


--
-- Name: menu_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_units (
    menu_unit_id bigint NOT NULL,
    value numeric(15,2) DEFAULT 0.00 NOT NULL,
    abbreaviation character varying(255) NOT NULL
);


ALTER TABLE public.menu_units OWNER TO postgres;

--
-- Name: menu_units_menu_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_units_menu_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_units_menu_unit_id_seq OWNER TO postgres;

--
-- Name: menu_units_menu_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_units_menu_unit_id_seq OWNED BY public.menu_units.menu_unit_id;


--
-- Name: mpesa_till; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mpesa_till (
    mpesa_till_id bigint NOT NULL,
    mpesa_till_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone
);


ALTER TABLE public.mpesa_till OWNER TO postgres;

--
-- Name: mpesa_till_mpesa_till_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mpesa_till_mpesa_till_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mpesa_till_mpesa_till_id_seq OWNER TO postgres;

--
-- Name: mpesa_till_mpesa_till_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mpesa_till_mpesa_till_id_seq OWNED BY public.mpesa_till.mpesa_till_id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_name character varying(255) NOT NULL,
    role_description text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    role_id bigint NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_role_id_seq OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- Name: shift; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shift (
    shift_id bigint NOT NULL,
    shift_start timestamp with time zone NOT NULL,
    shift_end timestamp with time zone NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE public.shift OWNER TO postgres;

--
-- Name: shift_shift_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shift_shift_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shift_shift_id_seq OWNER TO postgres;

--
-- Name: shift_shift_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shift_shift_id_seq OWNED BY public.shift.shift_id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    staff_id bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    email character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer,
    payroll_category integer,
    is_active boolean DEFAULT true
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_staff_id_seq OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_staff_id_seq OWNED BY public.staff.staff_id;


--
-- Name: station; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.station (
    station_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    name character varying(200) NOT NULL,
    lead_staff_id integer NOT NULL
);


ALTER TABLE public.station OWNER TO postgres;

--
-- Name: station_station_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.station_station_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.station_station_id_seq OWNER TO postgres;

--
-- Name: station_station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.station_station_id_seq OWNED BY public.station.station_id;


--
-- Name: stock_take_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_take_header (
    stock_take_header_id bigint NOT NULL,
    stock_take_date date,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stock_take_header OWNER TO postgres;

--
-- Name: stock_take_header_stock_take_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_take_header_stock_take_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_take_header_stock_take_header_id_seq OWNER TO postgres;

--
-- Name: stock_take_header_stock_take_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_take_header_stock_take_header_id_seq OWNED BY public.stock_take_header.stock_take_header_id;


--
-- Name: stock_take_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_take_line (
    stock_take_line_id bigint NOT NULL,
    stock_take_header_id integer NOT NULL,
    item_id integer NOT NULL,
    physical_quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    system_quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    variance numeric(15,2) DEFAULT 0.00 NOT NULL,
    viance_reason text
);


ALTER TABLE public.stock_take_line OWNER TO postgres;

--
-- Name: stock_take_line_stock_take_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_take_line_stock_take_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_take_line_stock_take_line_id_seq OWNER TO postgres;

--
-- Name: stock_take_line_stock_take_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_take_line_stock_take_line_id_seq OWNED BY public.stock_take_line.stock_take_line_id;


--
-- Name: store_issue_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_issue_header (
    store_issue_header_id bigint NOT NULL,
    issue_date date NOT NULL,
    description text NOT NULL,
    issued_by integer NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.store_issue_header OWNER TO postgres;

--
-- Name: store_issue_header_store_issue_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_issue_header_store_issue_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_issue_header_store_issue_header_id_seq OWNER TO postgres;

--
-- Name: store_issue_header_store_issue_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_issue_header_store_issue_header_id_seq OWNED BY public.store_issue_header.store_issue_header_id;


--
-- Name: store_issue_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_issue_line (
    store_issue_line_id bigint NOT NULL,
    store_item_id integer NOT NULL,
    issue_quantity numeric(15,2) NOT NULL,
    initial_value numeric(15,2) NOT NULL,
    final_value numeric(15,2) NOT NULL,
    store_issue_header_id integer NOT NULL
);


ALTER TABLE public.store_issue_line OWNER TO postgres;

--
-- Name: store_issue_line_store_issue_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_issue_line_store_issue_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_issue_line_store_issue_line_id_seq OWNER TO postgres;

--
-- Name: store_issue_line_store_issue_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_issue_line_store_issue_line_id_seq OWNED BY public.store_issue_line.store_issue_line_id;


--
-- Name: store_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_item (
    store_item_id bigint NOT NULL,
    store_id integer NOT NULL,
    item_id integer NOT NULL,
    quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    buying_price numeric(15,2) DEFAULT 0.00 NOT NULL,
    selling_price numeric(15,2) DEFAULT 0.00 NOT NULL,
    item_unit integer NOT NULL,
    item_category integer NOT NULL,
    item_status boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.store_item OWNER TO postgres;

--
-- Name: store_item_store_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_item_store_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_item_store_item_id_seq OWNER TO postgres;

--
-- Name: store_item_store_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_item_store_item_id_seq OWNED BY public.store_item.store_item_id;


--
-- Name: store_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_register (
    store_id bigint NOT NULL,
    store_name character varying(255) NOT NULL,
    created_at timestamp with time zone,
    location character varying(255)
);


ALTER TABLE public.store_register OWNER TO postgres;

--
-- Name: store_register_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_register_store_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_register_store_id_seq OWNER TO postgres;

--
-- Name: store_register_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_register_store_id_seq OWNED BY public.store_register.store_id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    phone character varying(255) NOT NULL,
    balance numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    is_active boolean DEFAULT true,
    supplier_name character varying(200) NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suppliers_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suppliers_supplier_id_seq OWNER TO postgres;

--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suppliers_supplier_id_seq OWNED BY public.suppliers.supplier_id;


--
-- Name: test_menu_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_menu_item (
    menu_register_id bigint NOT NULL
);


ALTER TABLE public.test_menu_item OWNER TO postgres;

--
-- Name: test_menu_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_menu_register (
    menu_register_id bigint NOT NULL
);


ALTER TABLE public.test_menu_register OWNER TO postgres;

--
-- Name: test_menu_register_menu_register_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_menu_register_menu_register_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.test_menu_register_menu_register_id_seq OWNER TO postgres;

--
-- Name: test_menu_register_menu_register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_menu_register_menu_register_id_seq OWNED BY public.test_menu_register.menu_register_id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_role_id bigint NOT NULL,
    role_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_user_role_id_seq OWNER TO postgres;

--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_user_role_id_seq OWNED BY public.user_roles.user_role_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255),
    ttl numeric(10,2) DEFAULT 120,
    phone character varying(200) NOT NULL,
    user_id bigint NOT NULL,
    first_name character varying(200) NOT NULL,
    last_name character varying(200) NOT NULL,
    is_active boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: vendor_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor_entries (
    vendor_entry_id bigint NOT NULL,
    vendor_id bigint NOT NULL,
    description text NOT NULL,
    credited numeric(15,2) NOT NULL,
    debited numeric(15,2) NOT NULL,
    balance numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255)
);


ALTER TABLE public.vendor_entries OWNER TO postgres;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors (
    vendor_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    balance numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    is_active boolean DEFAULT true,
    vendor_id bigint NOT NULL
);


ALTER TABLE public.vendors OWNER TO postgres;

--
-- Name: vendors_vendor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendors_vendor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendors_vendor_id_seq OWNER TO postgres;

--
-- Name: vendors_vendor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendors_vendor_id_seq OWNED BY public.vendors.vendor_id;


--
-- Name: waitstaff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.waitstaff_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.waitstaff_id_seq OWNER TO postgres;

--
-- Name: waitstaff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waitstaff (
    waitstaff_id bigint DEFAULT nextval('public.waitstaff_id_seq'::regclass) NOT NULL,
    waitstaff_name character varying(255) NOT NULL,
    waitstaff_phone character varying(255) NOT NULL,
    waitstaff_national_id character varying(255) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    pin integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean NOT NULL,
    created_by character varying(255),
    CONSTRAINT waitstaff_pin_check CHECK (((pin >= 100) AND (pin <= 999)))
);


ALTER TABLE public.waitstaff OWNER TO postgres;

--
-- Name: accounts account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN account_id SET DEFAULT nextval('public.accounts_account_id_seq'::regclass);


--
-- Name: banks bank_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks ALTER COLUMN bank_id SET DEFAULT nextval('public.banks_bank_id_seq'::regclass);


--
-- Name: cash_accounts cash_account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_accounts ALTER COLUMN cash_account_id SET DEFAULT nextval('public.cash_accounts_cash_account_id_seq'::regclass);


--
-- Name: food_processing_header food_processing_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header ALTER COLUMN food_processing_header_id SET DEFAULT nextval('public.food_processing_header_food_processing_header_id_seq'::regclass);


--
-- Name: food_processing_line food_processing_line_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line ALTER COLUMN food_processing_line_id SET DEFAULT nextval('public.food_processing_line_food_processing_line_id_seq'::regclass);


--
-- Name: fund_transfer fund_transfer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_transfer ALTER COLUMN fund_transfer_id SET DEFAULT nextval('public.fund_transfer_fund_transfer_id_seq'::regclass);


--
-- Name: gl_accounts gl_account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_accounts ALTER COLUMN gl_account_id SET DEFAULT nextval('public.gl_accounts_gl_account_id_seq'::regclass);


--
-- Name: item_category category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_category ALTER COLUMN category_id SET DEFAULT nextval('public.item_category_category_id_seq'::regclass);


--
-- Name: item_register item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register ALTER COLUMN item_id SET DEFAULT nextval('public.item_register_item_id_seq'::regclass);


--
-- Name: item_tracking item_tracking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking ALTER COLUMN item_tracking_id SET DEFAULT nextval('public.item_tracking_item_tracking_id_seq'::regclass);


--
-- Name: item_unit unit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_unit ALTER COLUMN unit_id SET DEFAULT nextval('public.item_unit_unit_id_seq'::regclass);


--
-- Name: kitchen_ingredients ingredient_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients ALTER COLUMN ingredient_id SET DEFAULT nextval('public.kitchen_ingredients_ingredient_id_seq'::regclass);


--
-- Name: kitchen_setup kitchen_setup_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup ALTER COLUMN kitchen_setup_id SET DEFAULT nextval('public.kitchen_setup_kitchen_setup_id_seq'::regclass);


--
-- Name: kitchen_setup_header kitchen_setup_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header ALTER COLUMN kitchen_setup_header_id SET DEFAULT nextval('public.kitchen_setup_header_kitchen_setup_header_id_seq'::regclass);


--
-- Name: menu_category menu_category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category ALTER COLUMN menu_category_id SET DEFAULT nextval('public.menu_category_menu_category_id_seq'::regclass);


--
-- Name: menu_item menu_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item ALTER COLUMN menu_item_id SET DEFAULT nextval('public.menu_item_menu_item_id_seq'::regclass);


--
-- Name: menu_register menu_register_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register ALTER COLUMN menu_register_id SET DEFAULT nextval('public.menu_register_menu_register_id_seq'::regclass);


--
-- Name: menu_unit menu_unit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_unit ALTER COLUMN menu_unit_id SET DEFAULT nextval('public.menu_unit_menu_unit_id_seq'::regclass);


--
-- Name: menu_units menu_unit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_units ALTER COLUMN menu_unit_id SET DEFAULT nextval('public.menu_units_menu_unit_id_seq'::regclass);


--
-- Name: mpesa_till mpesa_till_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till ALTER COLUMN mpesa_till_id SET DEFAULT nextval('public.mpesa_till_mpesa_till_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: shift shift_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift ALTER COLUMN shift_id SET DEFAULT nextval('public.shift_shift_id_seq'::regclass);


--
-- Name: staff staff_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN staff_id SET DEFAULT nextval('public.staff_staff_id_seq'::regclass);


--
-- Name: station station_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station ALTER COLUMN station_id SET DEFAULT nextval('public.station_station_id_seq'::regclass);


--
-- Name: stock_take_header stock_take_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_header ALTER COLUMN stock_take_header_id SET DEFAULT nextval('public.stock_take_header_stock_take_header_id_seq'::regclass);


--
-- Name: stock_take_line stock_take_line_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line ALTER COLUMN stock_take_line_id SET DEFAULT nextval('public.stock_take_line_stock_take_line_id_seq'::regclass);


--
-- Name: store_issue_header store_issue_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_header ALTER COLUMN store_issue_header_id SET DEFAULT nextval('public.store_issue_header_store_issue_header_id_seq'::regclass);


--
-- Name: store_issue_line store_issue_line_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_line ALTER COLUMN store_issue_line_id SET DEFAULT nextval('public.store_issue_line_store_issue_line_id_seq'::regclass);


--
-- Name: store_item store_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item ALTER COLUMN store_item_id SET DEFAULT nextval('public.store_item_store_item_id_seq'::regclass);


--
-- Name: store_register store_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_register ALTER COLUMN store_id SET DEFAULT nextval('public.store_register_store_id_seq'::regclass);


--
-- Name: suppliers supplier_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplier_id SET DEFAULT nextval('public.suppliers_supplier_id_seq'::regclass);


--
-- Name: test_menu_register menu_register_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_menu_register ALTER COLUMN menu_register_id SET DEFAULT nextval('public.test_menu_register_menu_register_id_seq'::regclass);


--
-- Name: user_roles user_role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN user_role_id SET DEFAULT nextval('public.user_roles_user_role_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: vendors vendor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors ALTER COLUMN vendor_id SET DEFAULT nextval('public.vendors_vendor_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (account_id, account_name, balance, created_by, created_at, gl_account_id) FROM stdin;
\.
COPY public.accounts (account_id, account_name, balance, created_by, created_at, gl_account_id) FROM '$$PATH$$/3767.dat';

--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banks (bank_id, bank_name, balance, created_by, created_at, bank_number) FROM stdin;
\.
COPY public.banks (bank_id, bank_name, balance, created_by, created_at, bank_number) FROM '$$PATH$$/3771.dat';

--
-- Data for Name: cash_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cash_accounts (cash_account_id, cash_account_name, balance, created_by, created_at) FROM stdin;
\.
COPY public.cash_accounts (cash_account_id, cash_account_name, balance, created_by, created_at) FROM '$$PATH$$/3773.dat';

--
-- Data for Name: food_processing_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_processing_header (food_processing_header_id, name, shift_id, created_by) FROM stdin;
\.
COPY public.food_processing_header (food_processing_header_id, name, shift_id, created_by) FROM '$$PATH$$/3795.dat';

--
-- Data for Name: food_processing_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_processing_line (food_processing_line_id, food_processing_header_id, name, station_id, kitchen_setup_id, created_at, created_by) FROM stdin;
\.
COPY public.food_processing_line (food_processing_line_id, food_processing_header_id, name, station_id, kitchen_setup_id, created_at, created_by) FROM '$$PATH$$/3801.dat';

--
-- Data for Name: fund_transfer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fund_transfer (fund_transfer_id, src_account_name, des_account_name, src_account_balance, des_account_balance, amount, created_at, src_accound_id, des_accound_id) FROM stdin;
\.
COPY public.fund_transfer (fund_transfer_id, src_account_name, des_account_name, src_account_balance, des_account_balance, amount, created_at, src_accound_id, des_accound_id) FROM '$$PATH$$/3775.dat';

--
-- Data for Name: gl_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_accounts (gl_account_id, gl_account_name, balance, created_by, created_at) FROM stdin;
\.
COPY public.gl_accounts (gl_account_id, gl_account_name, balance, created_by, created_at) FROM '$$PATH$$/3769.dat';

--
-- Data for Name: item_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_category (category_id, category_name, category_description, created_at) FROM stdin;
\.
COPY public.item_category (category_id, category_name, category_description, created_at) FROM '$$PATH$$/3785.dat';

--
-- Data for Name: item_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_register (item_id, item_name, item_description, item_status, created_by, created_at) FROM stdin;
\.
COPY public.item_register (item_id, item_name, item_description, item_status, created_by, created_at) FROM '$$PATH$$/3779.dat';

--
-- Data for Name: item_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_tracking (item_tracking_id, item_id, initial_balance, current_balance, net_change, reason, action_by) FROM stdin;
\.
COPY public.item_tracking (item_tracking_id, item_id, initial_balance, current_balance, net_change, reason, action_by) FROM '$$PATH$$/3789.dat';

--
-- Data for Name: item_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_unit (unit_id, standard_unit_name, standard_unit_value, other_unit_name, other_unit_value, created_at) FROM stdin;
\.
COPY public.item_unit (unit_id, standard_unit_name, standard_unit_value, other_unit_name, other_unit_value, created_at) FROM '$$PATH$$/3781.dat';

--
-- Data for Name: kitchen_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_ingredients (ingredient_id, ingredients_id, quantity, store_item_id) FROM stdin;
\.
COPY public.kitchen_ingredients (ingredient_id, ingredients_id, quantity, store_item_id) FROM '$$PATH$$/3822.dat';

--
-- Data for Name: kitchen_setup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_setup (kitchen_setup_id, name, station_id, created_at, menu_item_id) FROM stdin;
\.
COPY public.kitchen_setup (kitchen_setup_id, name, station_id, created_at, menu_item_id) FROM '$$PATH$$/3799.dat';

--
-- Data for Name: kitchen_setup_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_setup_header (kitchen_setup_header_id, menu_register_id, quanity, menu_unit_id) FROM stdin;
\.
COPY public.kitchen_setup_header (kitchen_setup_header_id, menu_register_id, quanity, menu_unit_id) FROM '$$PATH$$/3814.dat';

--
-- Data for Name: menu_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_category (menu_category_id, description, category_name, category_abbr, created_at) FROM stdin;
\.
COPY public.menu_category (menu_category_id, description, category_name, category_abbr, created_at) FROM '$$PATH$$/3808.dat';

--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_item (menu_item_id, menu_register_id, quantity, price, menu_category_id, available, created_at) FROM stdin;
\.
COPY public.menu_item (menu_item_id, menu_register_id, quantity, price, menu_category_id, available, created_at) FROM '$$PATH$$/3810.dat';

--
-- Data for Name: menu_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_register (menu_register_id, name, description, active, created_at, created_by) FROM stdin;
\.
COPY public.menu_register (menu_register_id, name, description, active, created_at, created_by) FROM '$$PATH$$/3806.dat';

--
-- Data for Name: menu_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_unit (menu_unit_id, unit_name, unit_abbr, value, created_at) FROM stdin;
\.
COPY public.menu_unit (menu_unit_id, unit_name, unit_abbr, value, created_at) FROM '$$PATH$$/3820.dat';

--
-- Data for Name: menu_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_units (menu_unit_id, value, abbreaviation) FROM stdin;
\.
COPY public.menu_units (menu_unit_id, value, abbreaviation) FROM '$$PATH$$/3812.dat';

--
-- Data for Name: mpesa_till; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mpesa_till (mpesa_till_id, mpesa_till_name, balance, created_by, created_at) FROM stdin;
\.
COPY public.mpesa_till (mpesa_till_id, mpesa_till_name, balance, created_by, created_at) FROM '$$PATH$$/3777.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_name, role_description, created_at, role_id, created_by) FROM stdin;
\.
COPY public.roles (role_name, role_description, created_at, role_id, created_by) FROM '$$PATH$$/3749.dat';

--
-- Data for Name: shift; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shift (shift_id, shift_start, shift_end, created_by) FROM stdin;
\.
COPY public.shift (shift_id, shift_start, shift_end, created_by) FROM '$$PATH$$/3764.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (staff_id, first_name, last_name, phone, email, created_at, created_by, payroll_category, is_active) FROM stdin;
\.
COPY public.staff (staff_id, first_name, last_name, phone, email, created_at, created_by, payroll_category, is_active) FROM '$$PATH$$/3756.dat';

--
-- Data for Name: station; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.station (station_id, created_at, name, lead_staff_id) FROM stdin;
\.
COPY public.station (station_id, created_at, name, lead_staff_id) FROM '$$PATH$$/3797.dat';

--
-- Data for Name: stock_take_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_take_header (stock_take_header_id, stock_take_date, created_by, created_at) FROM stdin;
\.
COPY public.stock_take_header (stock_take_header_id, stock_take_date, created_by, created_at) FROM '$$PATH$$/3791.dat';

--
-- Data for Name: stock_take_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_take_line (stock_take_line_id, stock_take_header_id, item_id, physical_quantity, system_quantity, variance, viance_reason) FROM stdin;
\.
COPY public.stock_take_line (stock_take_line_id, stock_take_header_id, item_id, physical_quantity, system_quantity, variance, viance_reason) FROM '$$PATH$$/3793.dat';

--
-- Data for Name: store_issue_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_issue_header (store_issue_header_id, issue_date, description, issued_by, created_by, created_at) FROM stdin;
\.
COPY public.store_issue_header (store_issue_header_id, issue_date, description, issued_by, created_by, created_at) FROM '$$PATH$$/3816.dat';

--
-- Data for Name: store_issue_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_issue_line (store_issue_line_id, store_item_id, issue_quantity, initial_value, final_value, store_issue_header_id) FROM stdin;
\.
COPY public.store_issue_line (store_issue_line_id, store_item_id, issue_quantity, initial_value, final_value, store_issue_header_id) FROM '$$PATH$$/3818.dat';

--
-- Data for Name: store_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_item (store_item_id, store_id, item_id, quantity, buying_price, selling_price, item_unit, item_category, item_status, created_at) FROM stdin;
\.
COPY public.store_item (store_item_id, store_id, item_id, quantity, buying_price, selling_price, item_unit, item_category, item_status, created_at) FROM '$$PATH$$/3787.dat';

--
-- Data for Name: store_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_register (store_id, store_name, created_at, location) FROM stdin;
\.
COPY public.store_register (store_id, store_name, created_at, location) FROM '$$PATH$$/3783.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (phone, balance, created_at, created_by, is_active, supplier_name, supplier_id) FROM stdin;
\.
COPY public.suppliers (phone, balance, created_at, created_by, is_active, supplier_name, supplier_id) FROM '$$PATH$$/3757.dat';

--
-- Data for Name: test_menu_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_menu_item (menu_register_id) FROM stdin;
\.
COPY public.test_menu_item (menu_register_id) FROM '$$PATH$$/3804.dat';

--
-- Data for Name: test_menu_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_menu_register (menu_register_id) FROM stdin;
\.
COPY public.test_menu_register (menu_register_id) FROM '$$PATH$$/3803.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_role_id, role_id, user_id, created_at) FROM stdin;
\.
COPY public.user_roles (user_role_id, role_id, user_id, created_at) FROM '$$PATH$$/3760.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, password, created_at, created_by, ttl, phone, user_id, first_name, last_name, is_active) FROM stdin;
\.
COPY public.users (username, password, created_at, created_by, ttl, phone, user_id, first_name, last_name, is_active) FROM '$$PATH$$/3753.dat';

--
-- Data for Name: vendor_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor_entries (vendor_entry_id, vendor_id, description, credited, debited, balance, created_at, created_by) FROM stdin;
\.
COPY public.vendor_entries (vendor_entry_id, vendor_id, description, credited, debited, balance, created_at, created_by) FROM '$$PATH$$/3752.dat';

--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors (vendor_name, phone, balance, created_at, created_by, is_active, vendor_id) FROM stdin;
\.
COPY public.vendors (vendor_name, phone, balance, created_at, created_by, is_active, vendor_id) FROM '$$PATH$$/3758.dat';

--
-- Data for Name: waitstaff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waitstaff (waitstaff_id, waitstaff_name, waitstaff_phone, waitstaff_national_id, balance, pin, created_at, is_active, created_by) FROM stdin;
\.
COPY public.waitstaff (waitstaff_id, waitstaff_name, waitstaff_phone, waitstaff_national_id, balance, pin, created_at, is_active, created_by) FROM '$$PATH$$/3751.dat';

--
-- Name: accounts_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_account_id_seq', 8, true);


--
-- Name: banks_bank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banks_bank_id_seq', 2, true);


--
-- Name: cash_accounts_cash_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cash_accounts_cash_account_id_seq', 2, true);


--
-- Name: custom_id_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_id_sequence', 2, true);


--
-- Name: food_processing_header_food_processing_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.food_processing_header_food_processing_header_id_seq', 1, false);


--
-- Name: food_processing_line_food_processing_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.food_processing_line_food_processing_line_id_seq', 1, false);


--
-- Name: fund_transfer_fund_transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fund_transfer_fund_transfer_id_seq', 1, false);


--
-- Name: gl_accounts_gl_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gl_accounts_gl_account_id_seq', 2, true);


--
-- Name: item_category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_category_category_id_seq', 8, true);


--
-- Name: item_register_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_register_item_id_seq', 7, true);


--
-- Name: item_tracking_item_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_tracking_item_tracking_id_seq', 1, false);


--
-- Name: item_unit_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_unit_unit_id_seq', 2, true);


--
-- Name: kitchen_ingredients_ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitchen_ingredients_ingredient_id_seq', 4, true);


--
-- Name: kitchen_setup_header_kitchen_setup_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitchen_setup_header_kitchen_setup_header_id_seq', 1, false);


--
-- Name: kitchen_setup_kitchen_setup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitchen_setup_kitchen_setup_id_seq', 11, true);


--
-- Name: menu_category_menu_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_category_menu_category_id_seq', 14, true);


--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_item_menu_item_id_seq', 16, true);


--
-- Name: menu_register_menu_register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_register_menu_register_id_seq', 18, true);


--
-- Name: menu_unit_menu_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_unit_menu_unit_id_seq', 7, true);


--
-- Name: menu_units_menu_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_units_menu_unit_id_seq', 1, false);


--
-- Name: mpesa_till_mpesa_till_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mpesa_till_mpesa_till_id_seq', 1, false);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 18, true);


--
-- Name: shift_shift_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shift_shift_id_seq', 4, true);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 5, true);


--
-- Name: station_station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.station_station_id_seq', 3, true);


--
-- Name: stock_take_header_stock_take_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_take_header_stock_take_header_id_seq', 1, false);


--
-- Name: stock_take_line_stock_take_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_take_line_stock_take_line_id_seq', 1, false);


--
-- Name: store_issue_header_store_issue_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_issue_header_store_issue_header_id_seq', 14, true);


--
-- Name: store_issue_line_store_issue_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_issue_line_store_issue_line_id_seq', 6, true);


--
-- Name: store_item_store_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_item_store_item_id_seq', 27, true);


--
-- Name: store_register_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_register_store_id_seq', 1, true);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_supplier_id_seq', 2, true);


--
-- Name: test_menu_register_menu_register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_menu_register_menu_register_id_seq', 1, false);


--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_user_role_id_seq', 77, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 38, true);


--
-- Name: vendors_vendor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendors_vendor_id_seq', 18, true);


--
-- Name: waitstaff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.waitstaff_id_seq', 100, false);


--
-- Name: accounts accounts_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_name_key UNIQUE (account_name);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: banks banks_bank_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_bank_name_key UNIQUE (bank_name);


--
-- Name: banks banks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (bank_id);


--
-- Name: cash_accounts cash_accounts_cash_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_cash_account_name_key UNIQUE (cash_account_name);


--
-- Name: cash_accounts cash_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_pkey PRIMARY KEY (cash_account_id);


--
-- Name: food_processing_header food_processing_header_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_name_key UNIQUE (name);


--
-- Name: food_processing_header food_processing_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_pkey PRIMARY KEY (food_processing_header_id);


--
-- Name: food_processing_line food_processing_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_pkey PRIMARY KEY (food_processing_line_id);


--
-- Name: fund_transfer fund_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_transfer
    ADD CONSTRAINT fund_transfer_pkey PRIMARY KEY (fund_transfer_id);


--
-- Name: gl_accounts gl_accounts_gl_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_accounts
    ADD CONSTRAINT gl_accounts_gl_account_name_key UNIQUE (gl_account_name);


--
-- Name: gl_accounts gl_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_accounts
    ADD CONSTRAINT gl_accounts_pkey PRIMARY KEY (gl_account_id);


--
-- Name: item_category item_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_category
    ADD CONSTRAINT item_category_pkey PRIMARY KEY (category_id);


--
-- Name: item_register item_register_item_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register
    ADD CONSTRAINT item_register_item_name_key UNIQUE (item_name);


--
-- Name: item_register item_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register
    ADD CONSTRAINT item_register_pkey PRIMARY KEY (item_id);


--
-- Name: item_tracking item_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking
    ADD CONSTRAINT item_tracking_pkey PRIMARY KEY (item_tracking_id);


--
-- Name: item_unit item_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_unit
    ADD CONSTRAINT item_unit_pkey PRIMARY KEY (unit_id);


--
-- Name: kitchen_ingredients kitchen_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients
    ADD CONSTRAINT kitchen_ingredients_pkey PRIMARY KEY (ingredient_id);


--
-- Name: kitchen_setup_header kitchen_setup_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header
    ADD CONSTRAINT kitchen_setup_header_pkey PRIMARY KEY (kitchen_setup_header_id);


--
-- Name: kitchen_setup kitchen_setup_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_name_key UNIQUE (name);


--
-- Name: kitchen_setup kitchen_setup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_pkey PRIMARY KEY (kitchen_setup_id);


--
-- Name: menu_category menu_category_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_category_name_key UNIQUE (category_name);


--
-- Name: menu_category menu_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_pkey PRIMARY KEY (menu_category_id);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (menu_item_id);


--
-- Name: menu_register menu_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register
    ADD CONSTRAINT menu_register_pkey PRIMARY KEY (menu_register_id);


--
-- Name: menu_unit menu_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_unit
    ADD CONSTRAINT menu_unit_pkey PRIMARY KEY (menu_unit_id);


--
-- Name: menu_units menu_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_units
    ADD CONSTRAINT menu_units_pkey PRIMARY KEY (menu_unit_id);


--
-- Name: mpesa_till mpesa_till_mpesa_till_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till
    ADD CONSTRAINT mpesa_till_mpesa_till_name_key UNIQUE (mpesa_till_name);


--
-- Name: mpesa_till mpesa_till_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till
    ADD CONSTRAINT mpesa_till_pkey PRIMARY KEY (mpesa_till_id);


--
-- Name: users phone_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT phone_unique UNIQUE (phone);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: shift shift_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift
    ADD CONSTRAINT shift_pkey PRIMARY KEY (shift_id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: station station_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_name_key UNIQUE (name);


--
-- Name: station station_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_pkey PRIMARY KEY (station_id);


--
-- Name: stock_take_header stock_take_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_header
    ADD CONSTRAINT stock_take_header_pkey PRIMARY KEY (stock_take_header_id);


--
-- Name: stock_take_line stock_take_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line
    ADD CONSTRAINT stock_take_line_pkey PRIMARY KEY (stock_take_line_id);


--
-- Name: store_issue_header store_issue_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_header
    ADD CONSTRAINT store_issue_header_pkey PRIMARY KEY (store_issue_header_id);


--
-- Name: store_issue_line store_issue_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_line
    ADD CONSTRAINT store_issue_line_pkey PRIMARY KEY (store_issue_line_id);


--
-- Name: store_item store_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_pkey PRIMARY KEY (store_item_id);


--
-- Name: store_register store_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_register
    ADD CONSTRAINT store_register_pkey PRIMARY KEY (store_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- Name: test_menu_register test_menu_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_menu_register
    ADD CONSTRAINT test_menu_register_pkey PRIMARY KEY (menu_register_id);


--
-- Name: item_category unique_category_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_category
    ADD CONSTRAINT unique_category_name UNIQUE (category_name);


--
-- Name: store_item unique_item_store; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT unique_item_store UNIQUE (item_id, store_id);


--
-- Name: menu_register unique_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register
    ADD CONSTRAINT unique_name UNIQUE (name);


--
-- Name: store_register unique_store_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_register
    ADD CONSTRAINT unique_store_name UNIQUE (store_name);


--
-- Name: menu_unit unique_unit_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_unit
    ADD CONSTRAINT unique_unit_name UNIQUE (unit_name);


--
-- Name: users unique_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT unique_username UNIQUE (username);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: vendor_entries vendor_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor_entries
    ADD CONSTRAINT vendor_entries_pkey PRIMARY KEY (vendor_entry_id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (vendor_id);


--
-- Name: waitstaff waitstaff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_pkey PRIMARY KEY (waitstaff_id);


--
-- Name: waitstaff waitstaff_waitstaff_national_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_waitstaff_national_id_key UNIQUE (waitstaff_national_id);


--
-- Name: waitstaff waitstaff_waitstaff_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_waitstaff_phone_key UNIQUE (waitstaff_phone);


--
-- Name: menu_item set_menu_availability; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_menu_availability BEFORE INSERT OR UPDATE ON public.menu_item FOR EACH ROW EXECUTE FUNCTION public.update_menu_availability();


--
-- Name: food_processing_header food_processing_header_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: food_processing_header food_processing_header_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shift(shift_id);


--
-- Name: food_processing_line food_processing_line_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: food_processing_line food_processing_line_food_processing_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_food_processing_header_id_fkey FOREIGN KEY (food_processing_header_id) REFERENCES public.food_processing_header(food_processing_header_id);


--
-- Name: food_processing_line food_processing_line_kitchen_setup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_kitchen_setup_id_fkey FOREIGN KEY (kitchen_setup_id) REFERENCES public.kitchen_setup(kitchen_setup_id);


--
-- Name: food_processing_line food_processing_line_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.station(station_id);


--
-- Name: item_register item_register_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register
    ADD CONSTRAINT item_register_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: item_tracking item_tracking_action_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking
    ADD CONSTRAINT item_tracking_action_by_fkey FOREIGN KEY (action_by) REFERENCES public.users(user_id);


--
-- Name: item_tracking item_tracking_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking
    ADD CONSTRAINT item_tracking_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: kitchen_ingredients kitchen_ingredients_ingredients_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients
    ADD CONSTRAINT kitchen_ingredients_ingredients_id_fkey FOREIGN KEY (ingredients_id) REFERENCES public.kitchen_setup(kitchen_setup_id);


--
-- Name: kitchen_ingredients kitchen_ingredients_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients
    ADD CONSTRAINT kitchen_ingredients_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: kitchen_setup_header kitchen_setup_header_menu_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header
    ADD CONSTRAINT kitchen_setup_header_menu_register_id_fkey FOREIGN KEY (menu_register_id) REFERENCES public.menu_register(menu_register_id);


--
-- Name: kitchen_setup_header kitchen_setup_header_menu_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header
    ADD CONSTRAINT kitchen_setup_header_menu_unit_id_fkey FOREIGN KEY (menu_unit_id) REFERENCES public.menu_units(menu_unit_id);


--
-- Name: kitchen_setup kitchen_setup_menu_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_menu_item_id_fkey FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id);


--
-- Name: kitchen_setup kitchen_setup_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.station(station_id);


--
-- Name: menu_item menu_item_menu_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_menu_category_id_fkey FOREIGN KEY (menu_category_id) REFERENCES public.menu_category(menu_category_id);


--
-- Name: menu_item menu_item_menu_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_menu_register_id_fkey FOREIGN KEY (menu_register_id) REFERENCES public.menu_register(menu_register_id);


--
-- Name: menu_register menu_register_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register
    ADD CONSTRAINT menu_register_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: station station_lead_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_lead_staff_id_fkey FOREIGN KEY (lead_staff_id) REFERENCES public.staff(staff_id);


--
-- Name: stock_take_header stock_take_header_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_header
    ADD CONSTRAINT stock_take_header_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: stock_take_line stock_take_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line
    ADD CONSTRAINT stock_take_line_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: stock_take_line stock_take_line_stock_take_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line
    ADD CONSTRAINT stock_take_line_stock_take_header_id_fkey FOREIGN KEY (stock_take_header_id) REFERENCES public.stock_take_header(stock_take_header_id);


--
-- Name: store_issue_line store_issue_line_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_line
    ADD CONSTRAINT store_issue_line_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: store_item store_item_item_category_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_item_category_fkey FOREIGN KEY (item_category) REFERENCES public.item_category(category_id);


--
-- Name: store_item store_item_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: store_item store_item_item_unit_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_item_unit_fkey FOREIGN KEY (item_unit) REFERENCES public.item_unit(unit_id);


--
-- Name: store_item store_item_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store_register(store_id);


--
-- Name: test_menu_item test_menu_item_menu_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_menu_item
    ADD CONSTRAINT test_menu_item_menu_register_id_fkey FOREIGN KEY (menu_register_id) REFERENCES public.test_menu_register(menu_register_id);


--
-- PostgreSQL database dump complete
--

