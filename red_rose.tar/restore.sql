--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.6
-- Dumped by pg_dump version 15.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE red_rose;
--
-- Name: red_rose; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE red_rose WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Kenya.1252';


ALTER DATABASE red_rose OWNER TO postgres;

\connect red_rose

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: get_ingredients(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_ingredients(food_items json) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    result JSON;
BEGIN
    -- Log the input food_items
    RAISE NOTICE 'Input food_items: %', food_items;

    -- Log each step of the process
    SELECT JSON_AGG(row_to_json(ingredients_row)) INTO result
    FROM (
        SELECT 
            store_item_id, 
            SUM(quantity * (food_items->>'quantity')::INT) AS total_quantity
        FROM 
            kitchen_ingredients
        WHERE 
            ingredients_id = (food_items->>'kitchen_setup_id')::INT
        GROUP BY store_item_id
    ) ingredients_row;

    -- Log the final result
    RAISE NOTICE 'Result: %', result;

    RETURN result;
END;
$$;


ALTER FUNCTION public.get_ingredients(food_items json) OWNER TO postgres;

--
-- Name: get_kitchen_ingredients_by_setup_id(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_kitchen_ingredients_by_setup_id(food_items json) RETURNS TABLE(ingredients_id integer, store_item_id integer, quantity numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
    item JSON;
    kitchen_setup_id INT;
    qty NUMERIC(15,2);
    ingredients_found INT;
BEGIN
    -- Loop through the JSON array to process each item
    FOR item IN 
        SELECT * FROM json_array_elements(food_items)  -- Get each JSON element
    LOOP
        -- Extract the kitchen_setup_id and quantity from the JSON object
        kitchen_setup_id := (item->>'kitchen_setup_id')::INT;
        qty := (item->>'quantity')::NUMERIC;

        -- Check if there are any ingredients matching the kitchen_setup_id
        SELECT COUNT(*)
        INTO ingredients_found
        FROM kitchen_ingredients ki
        WHERE ki.ingredients_id = kitchen_setup_id;

        -- If no ingredients found, raise an exception
        IF ingredients_found = 0 THEN
            RAISE EXCEPTION 'No ingredients found for kitchen_setup_id: %', kitchen_setup_id;
        END IF;

        -- Select the ingredients, multiplying quantity by the passed qty
        RETURN QUERY
        SELECT
            ki.ingredients_id,
            ki.store_item_id,
            ki.quantity * qty AS quantity  -- Multiply the quantity from the table by the qty
        FROM
            kitchen_ingredients ki
        WHERE
            ki.ingredients_id = kitchen_setup_id;
    END LOOP;
    
    -- If no results, return empty
    RETURN;
END;
$$;


ALTER FUNCTION public.get_kitchen_ingredients_by_setup_id(food_items json) OWNER TO postgres;

--
-- Name: insert_item_tracking(integer, numeric, numeric, numeric, character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_item_tracking(p_item_id integer, p_initial_balance numeric, p_current_balance numeric, p_net_change numeric, p_reason character varying, p_action_by integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO item_tracking (
        item_id, initial_balance, current_balance, net_change, reason, action_by, created_at
    )
    VALUES (
        p_item_id, p_initial_balance, p_current_balance, p_net_change, p_reason, p_action_by, NOW()
    );
END;
$$;


ALTER FUNCTION public.insert_item_tracking(p_item_id integer, p_initial_balance numeric, p_current_balance numeric, p_net_change numeric, p_reason character varying, p_action_by integer) OWNER TO postgres;

--
-- Name: sales_order_processing(json, json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sales_order_processing(menu_items json, store_items json) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    item JSON;
    pl_menu_item_id INT;
    pl_menu_qty NUMERIC(15, 2);
    current_quantity NUMERIC(15, 2);
    new_quantity NUMERIC(15, 2);

    pl_store_item_id INT;  -- Variable for store item ID
    pl_source_type VARCHAR(200); -- Variable for source type (MAIN_STORE or HOT_KITCHEN)
    pl_store_qty NUMERIC(15, 2); -- Store quantity to subtract
    store_current_quantity NUMERIC(15, 2);  -- Current quantity in store
    store_new_quantity NUMERIC(15, 2);      -- New quantity after update
BEGIN
    -- Process menu items
    FOR item IN
        SELECT * FROM json_array_elements(menu_items)
    LOOP
        pl_menu_item_id := (item->>'menu_item_id')::INT;
        pl_menu_qty := (item->>'quantity')::NUMERIC;

        -- Lock the row and fetch current quantity
        SELECT quantity
        INTO current_quantity
        FROM menu_item
        WHERE menu_item_id = pl_menu_item_id
        FOR UPDATE;

        -- Update the quantity
        UPDATE menu_item
        SET quantity = current_quantity + pl_menu_qty
        WHERE menu_item_id = pl_menu_item_id
        RETURNING quantity INTO new_quantity;

        -- Insert into menu tracking
        INSERT INTO menu_tracking (menu_item_id, current_quantity, new_quantity, reason)
        VALUES (pl_menu_item_id, current_quantity, new_quantity, 'Sales Order processing');
    END LOOP;

    -- Process store items
    FOR item IN
        SELECT * FROM json_array_elements(store_items)
    LOOP
        pl_store_item_id := (item->>'store_item_id')::INT;
        pl_source_type := (item->>'source_type')::VARCHAR;
        pl_store_qty := (item->>'quantity')::NUMERIC;

        IF pl_source_type = 'MAIN_STORE' THEN
		
            -- Lock the row and fetch current quantity
            SELECT quantity
            INTO store_current_quantity
            FROM store_item
            WHERE store_item_id = pl_store_item_id
            FOR UPDATE;

            -- Check and update the quantity
            IF store_current_quantity - pl_store_qty < 0 THEN
                RAISE EXCEPTION 'Quantity for store_item_id % would be negative', pl_store_item_id;
            END IF;

            UPDATE store_item
            SET quantity = store_current_quantity - pl_store_qty
            WHERE store_item_id = pl_store_item_id
            RETURNING quantity INTO store_new_quantity;

            -- Insert into item tracking
            INSERT INTO item_tracking (store_item_id, current_quantity, new_quantity, reason)
            VALUES (pl_store_item_id, store_current_quantity, store_new_quantity, 'Sales order processing');
        END IF;

        IF pl_source_type = 'HOT_KITCHEN' THEN
            -- Lock the row and fetch current quantity
            SELECT quantity
            INTO store_current_quantity
            FROM hot_kitchen_store
            WHERE store_item_id = pl_store_item_id
            FOR UPDATE;

            -- Check and update the quantity
            IF store_current_quantity - pl_store_qty < 0 THEN
                RAISE EXCEPTION 'Quantity for store_item_id % would be negative', pl_store_item_id;
            END IF;

            UPDATE hot_kitchen_store
            SET quantity = store_current_quantity - pl_store_qty
            WHERE store_item_id = pl_store_item_id
            RETURNING quantity INTO store_new_quantity;

            -- Insert into hot kitchen tracking
            INSERT INTO hot_kitchen_tracking (store_item_id, current_quantity, new_quantity, reason)
            VALUES (pl_store_item_id, store_current_quantity, store_new_quantity, 'Sales order processing');
        END IF;
    END LOOP;

END;
$$;


ALTER FUNCTION public.sales_order_processing(menu_items json, store_items json) OWNER TO postgres;

--
-- Name: store_transfer_procedure(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.store_transfer_procedure(store_item json) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    item JSON;
    pl_store_item_id INT; -- Variable to store store_item_id
    pl_qty NUMERIC(15, 2); -- Variable to store quantity
    s_current_quantity NUMERIC(15, 2); -- Current quantity in store_item
    s_new_quantity NUMERIC(15, 2); -- New quantity in store_item
    h_current_quantity NUMERIC(15, 2); -- Current quantity in hot_kitchen_store
    h_new_quantity NUMERIC(15, 2); -- New quantity in hot_kitchen_store
BEGIN
    -- Validate existence of all store_item_id in hot_kitchen_store
    IF EXISTS (
        SELECT 1
        FROM json_array_elements(store_item) AS items,
             LATERAL (
                 SELECT (items ->> 'store_item_id')::INT AS store_item_id
             ) AS item_ids
        LEFT JOIN hot_kitchen_store
        ON hot_kitchen_store.store_item_id = item_ids.store_item_id
        WHERE hot_kitchen_store.store_item_id IS NULL
    ) THEN
        RAISE EXCEPTION 'One or more store_item_id values do not exist in hot_kitchen_store';
    END IF;

    -- Process each item after validation
    FOR item IN
        SELECT * FROM json_array_elements(store_item)
    LOOP
        -- Extract store_item_id and quantity
        pl_store_item_id := (item ->> 'store_item_id')::INT;
        pl_qty := (item ->> 'quantity')::NUMERIC;

        -- Lock and check quantity in store_item
        SELECT quantity
        INTO s_current_quantity
        FROM store_item
        WHERE store_item_id = pl_store_item_id
        FOR UPDATE;

        -- Check if there is enough quantity in store_item
        IF s_current_quantity - pl_qty < 0 THEN
            RAISE EXCEPTION 'Quantity for store_item_id % in store_item would be negative', pl_store_item_id;
        ELSE
            -- Update store_item
            s_new_quantity := s_current_quantity - pl_qty;
            UPDATE store_item
            SET quantity = s_new_quantity
            WHERE store_item_id = pl_store_item_id;

            -- Log in item_tracking
            INSERT INTO item_tracking(store_item_id, current_quantity, new_quantity, reason)
            VALUES (pl_store_item_id, s_current_quantity, s_new_quantity, 'Transfer to hot kitchen');
        END IF;

        -- Lock and update hot_kitchen_store
        SELECT quantity
        INTO h_current_quantity
        FROM hot_kitchen_store
        WHERE store_item_id = pl_store_item_id
        FOR UPDATE;

        -- Update hot_kitchen_store
        h_new_quantity := h_current_quantity + pl_qty;
        UPDATE hot_kitchen_store
        SET quantity = h_new_quantity
        WHERE store_item_id = pl_store_item_id;

        -- Log in hot_kitchen_tracking
        INSERT INTO hot_kitchen_tracking(store_item_id, current_quantity, new_quantity, reason)
        VALUES (pl_store_item_id, h_current_quantity, h_new_quantity, 'Transfer from store');
    END LOOP;
END;
$$;


ALTER FUNCTION public.store_transfer_procedure(store_item json) OWNER TO postgres;

--
-- Name: update_menu_availability(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_menu_availability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Automatically set 'available' based on the value of 'quantity'
    IF NEW.quantity > 0 THEN
        NEW.available := true;
    ELSE
        NEW.available := false;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_menu_availability() OWNER TO postgres;

--
-- Name: update_menu_item_quantities(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_menu_item_quantities(food_items json) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    item JSON;
    pl_menu_item_id INT;
    pl_qty NUMERIC(15,2);
    current_quantity NUMERIC(15,2);
    new_quantity NUMERIC(15,2);
BEGIN
    -- Sort the JSON input by menu_item_id for consistent locking order
    FOR item IN
        SELECT * FROM json_array_elements(food_items)
        ORDER BY (item->>'menu_item_id')::INT  -- Sort by menu_item_id
    LOOP
        pl_menu_item_id := (item->>'menu_item_id')::INT;
        pl_qty := (item->>'quantity')::NUMERIC;

        FOR current_quantity IN
            SELECT mi.quantity
            FROM menu_item mi
            WHERE mi.menu_item_id = pl_menu_item_id
            FOR UPDATE
        LOOP
            IF pl_qty < 0 THEN
                RAISE EXCEPTION 'Quantity for menu_item_id % negative update not allowed', pl_menu_item_id;
            ELSE
                new_quantity := current_quantity + pl_qty;

                UPDATE menu_item
                SET quantity = new_quantity
                WHERE menu_item_id = pl_menu_item_id;

                INSERT INTO menu_tracking (menu_item_id, current_quantity, new_quantity, reason)
                VALUES (pl_menu_item_id, current_quantity, new_quantity, 'Food processing');
            END IF;
        END LOOP;
    END LOOP;
END;
$$;


ALTER FUNCTION public.update_menu_item_quantities(food_items json) OWNER TO postgres;

--
-- Name: update_store_item_quantities(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_store_item_quantities(food_items json) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    item JSON;
    pl_store_item_id INT; -- PL/pgSQL variable to store the store_item_id
    pl_qty NUMERIC(15, 2); -- PL/pgSQL variable to store the quantity
    current_quantity NUMERIC(15, 2); -- Variable to store the current quantity from store_item
    new_quantity NUMERIC(15, 2); -- Variable to store the new quantity after update
BEGIN
    -- Loop through the sorted JSON array to process each item
    FOR item IN
        -- Convert the JSON array into a set of records and sort by store_item_id
        SELECT * FROM json_array_elements(food_items) AS elem
        ORDER BY (elem ->> 'store_item_id')::INT
    LOOP
        -- Extract store_item_id and quantity from the JSON object
        pl_store_item_id := (item ->> 'store_item_id')::INT; -- Assign to PL/pgSQL variable
        pl_qty := (item ->> 'quantity')::NUMERIC; -- Assign to PL/pgSQL variable

        -- Lock the row for the store_item_id to prevent race conditions
        FOR current_quantity IN 
            SELECT si.quantity -- Explicitly qualify the column name
            FROM store_item si -- Explicitly qualify the table name
            WHERE si.store_item_id = pl_store_item_id -- Use the PL/pgSQL variable
            FOR UPDATE -- Row-level lock
        LOOP
            -- Check if the new quantity after update would be negative
            IF current_quantity - pl_qty < 0 THEN
                RAISE EXCEPTION 'Quantity for store_item_id % would be negative', pl_store_item_id;
            ELSE
                -- Calculate the new quantity after subtraction
                new_quantity := current_quantity - pl_qty;

                -- Update the store_item quantity with the new value
                UPDATE store_item
                SET quantity = new_quantity
                WHERE store_item_id = pl_store_item_id;

                -- Insert into item_tracking table to track the change
                INSERT INTO item_tracking(store_item_id, current_quantity, new_quantity, reason)
                VALUES(pl_store_item_id, current_quantity, new_quantity, 'Food processing');
            END IF;
        END LOOP;
    END LOOP;
END;
$$;


ALTER FUNCTION public.update_store_item_quantities(food_items json) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    account_id bigint NOT NULL,
    account_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone,
    gl_account_id integer
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_account_id_seq OWNER TO postgres;

--
-- Name: accounts_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_account_id_seq OWNED BY public.accounts.account_id;


--
-- Name: active_shift; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.active_shift (
    active_shfit_id bigint NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone
);


ALTER TABLE public.active_shift OWNER TO postgres;

--
-- Name: active_shift_active_shfit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.active_shift_active_shfit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.active_shift_active_shfit_id_seq OWNER TO postgres;

--
-- Name: active_shift_active_shfit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.active_shift_active_shfit_id_seq OWNED BY public.active_shift.active_shfit_id;


--
-- Name: banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banks (
    bank_id bigint NOT NULL,
    bank_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone,
    bank_number character varying(255) DEFAULT 0 NOT NULL
);


ALTER TABLE public.banks OWNER TO postgres;

--
-- Name: banks_bank_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.banks_bank_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banks_bank_id_seq OWNER TO postgres;

--
-- Name: banks_bank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.banks_bank_id_seq OWNED BY public.banks.bank_id;


--
-- Name: cancel_bills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cancel_bills (
    cancel_bill_id bigint NOT NULL,
    sales_order_details_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.cancel_bills OWNER TO postgres;

--
-- Name: cancel_bills_cancel_bill_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cancel_bills_cancel_bill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cancel_bills_cancel_bill_id_seq OWNER TO postgres;

--
-- Name: cancel_bills_cancel_bill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cancel_bills_cancel_bill_id_seq OWNED BY public.cancel_bills.cancel_bill_id;


--
-- Name: cash_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cash_accounts (
    cash_account_id bigint NOT NULL,
    cash_account_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone
);


ALTER TABLE public.cash_accounts OWNER TO postgres;

--
-- Name: cash_accounts_cash_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cash_accounts_cash_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cash_accounts_cash_account_id_seq OWNER TO postgres;

--
-- Name: cash_accounts_cash_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cash_accounts_cash_account_id_seq OWNED BY public.cash_accounts.cash_account_id;


--
-- Name: clear_bills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clear_bills (
    cancel_bill_id bigint NOT NULL,
    sales_order_details_id integer NOT NULL,
    clear_type character varying(200) NOT NULL,
    amount numeric(15,2) NOT NULL,
    balance numeric(15,2) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.clear_bills OWNER TO postgres;

--
-- Name: clear_bills_cancel_bill_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clear_bills_cancel_bill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clear_bills_cancel_bill_id_seq OWNER TO postgres;

--
-- Name: clear_bills_cancel_bill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clear_bills_cancel_bill_id_seq OWNED BY public.clear_bills.cancel_bill_id;


--
-- Name: custom_id_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_id_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_id_sequence OWNER TO postgres;

--
-- Name: food_processing_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_processing_header (
    food_processing_header_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    shift_id integer NOT NULL,
    created_by integer
);


ALTER TABLE public.food_processing_header OWNER TO postgres;

--
-- Name: food_processing_header_food_processing_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.food_processing_header_food_processing_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.food_processing_header_food_processing_header_id_seq OWNER TO postgres;

--
-- Name: food_processing_header_food_processing_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.food_processing_header_food_processing_header_id_seq OWNED BY public.food_processing_header.food_processing_header_id;


--
-- Name: food_processing_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_processing_line (
    food_processing_line_id bigint NOT NULL,
    food_processing_header_id integer NOT NULL,
    name character varying(255) NOT NULL,
    station_id integer NOT NULL,
    kitchen_setup_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL
);


ALTER TABLE public.food_processing_line OWNER TO postgres;

--
-- Name: food_processing_line_food_processing_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.food_processing_line_food_processing_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.food_processing_line_food_processing_line_id_seq OWNER TO postgres;

--
-- Name: food_processing_line_food_processing_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.food_processing_line_food_processing_line_id_seq OWNED BY public.food_processing_line.food_processing_line_id;


--
-- Name: fund_transfer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fund_transfer (
    fund_transfer_id bigint NOT NULL,
    src_account_name character varying(200) NOT NULL,
    des_account_name character varying(200) NOT NULL,
    src_account_balance numeric(15,2) DEFAULT 0,
    des_account_balance numeric(15,2) DEFAULT 0,
    amount numeric(15,2) DEFAULT 0,
    created_at timestamp with time zone,
    src_accound_id integer NOT NULL,
    des_accound_id integer NOT NULL
);


ALTER TABLE public.fund_transfer OWNER TO postgres;

--
-- Name: fund_transfer_fund_transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fund_transfer_fund_transfer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fund_transfer_fund_transfer_id_seq OWNER TO postgres;

--
-- Name: fund_transfer_fund_transfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fund_transfer_fund_transfer_id_seq OWNED BY public.fund_transfer.fund_transfer_id;


--
-- Name: gl_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_accounts (
    gl_account_id bigint NOT NULL,
    gl_account_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    created_at timestamp with time zone
);


ALTER TABLE public.gl_accounts OWNER TO postgres;

--
-- Name: gl_accounts_gl_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gl_accounts_gl_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gl_accounts_gl_account_id_seq OWNER TO postgres;

--
-- Name: gl_accounts_gl_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gl_accounts_gl_account_id_seq OWNED BY public.gl_accounts.gl_account_id;


--
-- Name: hot_kichen_store_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hot_kichen_store_tracking (
    hot_kichen_store_tracking_id bigint NOT NULL,
    item_id integer NOT NULL,
    intial_value numeric(15,2) NOT NULL,
    final_value numeric(15,2) NOT NULL,
    reason text,
    created_by integer
);


ALTER TABLE public.hot_kichen_store_tracking OWNER TO postgres;

--
-- Name: hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq OWNER TO postgres;

--
-- Name: hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq OWNED BY public.hot_kichen_store_tracking.hot_kichen_store_tracking_id;


--
-- Name: kitchen_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_store (
    kitchen_store_item_id bigint NOT NULL,
    quantity numeric(15,4) NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    item_id integer NOT NULL,
    store_item_id integer NOT NULL,
    selling_price numeric(15,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    store_id integer NOT NULL
);


ALTER TABLE public.kitchen_store OWNER TO postgres;

--
-- Name: hot_kitchen_store_hot_kitchen_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hot_kitchen_store_hot_kitchen_store_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hot_kitchen_store_hot_kitchen_store_id_seq OWNER TO postgres;

--
-- Name: hot_kitchen_store_hot_kitchen_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hot_kitchen_store_hot_kitchen_store_id_seq OWNED BY public.kitchen_store.kitchen_store_item_id;


--
-- Name: hot_kitchen_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hot_kitchen_tracking (
    hot_kitchen_tracking_id bigint NOT NULL,
    current_quantity numeric(15,2) NOT NULL,
    new_quantity numeric(15,2) NOT NULL,
    reason text,
    action_by integer DEFAULT 0 NOT NULL,
    store_item_id integer NOT NULL
);


ALTER TABLE public.hot_kitchen_tracking OWNER TO postgres;

--
-- Name: hot_kitchen_tracking_hot_kitchen_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hot_kitchen_tracking_hot_kitchen_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hot_kitchen_tracking_hot_kitchen_tracking_id_seq OWNER TO postgres;

--
-- Name: hot_kitchen_tracking_hot_kitchen_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hot_kitchen_tracking_hot_kitchen_tracking_id_seq OWNED BY public.hot_kitchen_tracking.hot_kitchen_tracking_id;


--
-- Name: item_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_category (
    category_id bigint NOT NULL,
    category_name character varying(255) NOT NULL,
    category_description text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.item_category OWNER TO postgres;

--
-- Name: item_category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_category_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_category_category_id_seq OWNER TO postgres;

--
-- Name: item_category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_category_category_id_seq OWNED BY public.item_category.category_id;


--
-- Name: item_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_register (
    item_id bigint NOT NULL,
    item_name character varying(255) NOT NULL,
    item_description text NOT NULL,
    item_status boolean DEFAULT true NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.item_register OWNER TO postgres;

--
-- Name: item_register_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_register_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_register_item_id_seq OWNER TO postgres;

--
-- Name: item_register_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_register_item_id_seq OWNED BY public.item_register.item_id;


--
-- Name: item_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_tracking (
    item_tracking_id bigint NOT NULL,
    store_item_id integer NOT NULL,
    current_quantity numeric(15,2) NOT NULL,
    new_quantity numeric(15,2) NOT NULL,
    reason text NOT NULL,
    action_by integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.item_tracking OWNER TO postgres;

--
-- Name: item_tracking_item_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_tracking_item_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_tracking_item_tracking_id_seq OWNER TO postgres;

--
-- Name: item_tracking_item_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_tracking_item_tracking_id_seq OWNED BY public.item_tracking.item_tracking_id;


--
-- Name: item_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_unit (
    unit_id bigint NOT NULL,
    standard_unit_name character varying(255) NOT NULL,
    standard_unit_value numeric(15,2) DEFAULT 0.00 NOT NULL,
    other_unit_name character varying(255) DEFAULT NULL::character varying,
    other_unit_value numeric(15,2) DEFAULT 0.00,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.item_unit OWNER TO postgres;

--
-- Name: item_unit_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_unit_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_unit_unit_id_seq OWNER TO postgres;

--
-- Name: item_unit_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_unit_unit_id_seq OWNED BY public.item_unit.unit_id;


--
-- Name: kitchen_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_ingredients (
    ingredient_id bigint NOT NULL,
    ingredients_id integer NOT NULL,
    quantity numeric(15,2) NOT NULL,
    store_item_id integer NOT NULL,
    source_type character varying(200) NOT NULL
);


ALTER TABLE public.kitchen_ingredients OWNER TO postgres;

--
-- Name: kitchen_ingredients_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitchen_ingredients_ingredient_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitchen_ingredients_ingredient_id_seq OWNER TO postgres;

--
-- Name: kitchen_ingredients_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitchen_ingredients_ingredient_id_seq OWNED BY public.kitchen_ingredients.ingredient_id;


--
-- Name: kitchen_setup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_setup (
    kitchen_setup_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    station_id integer NOT NULL,
    created_at timestamp with time zone,
    menu_item_id integer NOT NULL
);


ALTER TABLE public.kitchen_setup OWNER TO postgres;

--
-- Name: kitchen_setup_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kitchen_setup_header (
    kitchen_setup_header_id bigint NOT NULL,
    menu_register_id integer NOT NULL,
    quanity numeric(25,2) DEFAULT 0.00 NOT NULL,
    menu_unit_id integer
);


ALTER TABLE public.kitchen_setup_header OWNER TO postgres;

--
-- Name: kitchen_setup_header_kitchen_setup_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitchen_setup_header_kitchen_setup_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitchen_setup_header_kitchen_setup_header_id_seq OWNER TO postgres;

--
-- Name: kitchen_setup_header_kitchen_setup_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitchen_setup_header_kitchen_setup_header_id_seq OWNED BY public.kitchen_setup_header.kitchen_setup_header_id;


--
-- Name: kitchen_setup_kitchen_setup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kitchen_setup_kitchen_setup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kitchen_setup_kitchen_setup_id_seq OWNER TO postgres;

--
-- Name: kitchen_setup_kitchen_setup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kitchen_setup_kitchen_setup_id_seq OWNED BY public.kitchen_setup.kitchen_setup_id;


--
-- Name: menu_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_category (
    menu_category_id bigint NOT NULL,
    description text NOT NULL,
    category_name character varying(200) NOT NULL,
    category_abbr character varying(200),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.menu_category OWNER TO postgres;

--
-- Name: menu_category_menu_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_category_menu_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_category_menu_category_id_seq OWNER TO postgres;

--
-- Name: menu_category_menu_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_category_menu_category_id_seq OWNED BY public.menu_category.menu_category_id;


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_item (
    menu_item_id bigint NOT NULL,
    menu_register_id integer NOT NULL,
    quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    price numeric(15,2) DEFAULT 0.00 NOT NULL,
    menu_category_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    available boolean DEFAULT true
);


ALTER TABLE public.menu_item OWNER TO postgres;

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_item_menu_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_item_menu_item_id_seq OWNER TO postgres;

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNED BY public.menu_item.menu_item_id;


--
-- Name: menu_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_register (
    menu_register_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL
);


ALTER TABLE public.menu_register OWNER TO postgres;

--
-- Name: menu_register_menu_register_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_register_menu_register_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_register_menu_register_id_seq OWNER TO postgres;

--
-- Name: menu_register_menu_register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_register_menu_register_id_seq OWNED BY public.menu_register.menu_register_id;


--
-- Name: menu_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_tracking (
    menu_tracking_id bigint NOT NULL,
    menu_item_id integer NOT NULL,
    current_quantity numeric(15,2) NOT NULL,
    new_quantity numeric(15,2) NOT NULL,
    reason text,
    action_by integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.menu_tracking OWNER TO postgres;

--
-- Name: menu_tracking_menu_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_tracking_menu_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_tracking_menu_tracking_id_seq OWNER TO postgres;

--
-- Name: menu_tracking_menu_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_tracking_menu_tracking_id_seq OWNED BY public.menu_tracking.menu_tracking_id;


--
-- Name: menu_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_unit (
    menu_unit_id bigint NOT NULL,
    unit_name character varying(255) NOT NULL,
    unit_abbr character varying(255) NOT NULL,
    value numeric(15,2) NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.menu_unit OWNER TO postgres;

--
-- Name: menu_unit_menu_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_unit_menu_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_unit_menu_unit_id_seq OWNER TO postgres;

--
-- Name: menu_unit_menu_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_unit_menu_unit_id_seq OWNED BY public.menu_unit.menu_unit_id;


--
-- Name: menu_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_units (
    menu_unit_id bigint NOT NULL,
    value numeric(15,2) DEFAULT 0.00 NOT NULL,
    abbreaviation character varying(255) NOT NULL
);


ALTER TABLE public.menu_units OWNER TO postgres;

--
-- Name: menu_units_menu_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_units_menu_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_units_menu_unit_id_seq OWNER TO postgres;

--
-- Name: menu_units_menu_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_units_menu_unit_id_seq OWNED BY public.menu_units.menu_unit_id;


--
-- Name: mpesa_till; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mpesa_till (
    mpesa_till_id bigint NOT NULL,
    mpesa_till_name character varying(200) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    created_by integer,
    till_number character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mpesa_till OWNER TO postgres;

--
-- Name: mpesa_till_mpesa_till_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mpesa_till_mpesa_till_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mpesa_till_mpesa_till_id_seq OWNER TO postgres;

--
-- Name: mpesa_till_mpesa_till_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mpesa_till_mpesa_till_id_seq OWNED BY public.mpesa_till.mpesa_till_id;


--
-- Name: purchase_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_order (
    purchase_order_id bigint NOT NULL,
    purchase_order_total numeric(15,2) NOT NULL,
    purchase_order_type character varying(200) NOT NULL,
    vat_total numeric(15,2) NOT NULL,
    pay_type character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL
);


ALTER TABLE public.purchase_order OWNER TO postgres;

--
-- Name: purchase_order_purchase_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchase_order_purchase_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_order_purchase_order_id_seq OWNER TO postgres;

--
-- Name: purchase_order_purchase_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchase_order_purchase_order_id_seq OWNED BY public.purchase_order.purchase_order_id;


--
-- Name: purchase_requisition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_requisition (
    purchase_requisition_id bigint NOT NULL,
    purchase_requisition_total numeric(15,2) NOT NULL,
    purchase_requisition_type character varying(200) NOT NULL,
    vat_total numeric(15,2) NOT NULL,
    pay_type character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL
);


ALTER TABLE public.purchase_requisition OWNER TO postgres;

--
-- Name: purchase_requisition_purchase_requisition_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchase_requisition_purchase_requisition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchase_requisition_purchase_requisition_id_seq OWNER TO postgres;

--
-- Name: purchase_requisition_purchase_requisition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchase_requisition_purchase_requisition_id_seq OWNED BY public.purchase_requisition.purchase_requisition_id;


--
-- Name: restraurant_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restraurant_store (
    restraurant_store_item_id bigint NOT NULL,
    quantity numeric(15,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    item_id integer NOT NULL,
    store_item_id integer NOT NULL,
    selling_price numeric(15,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.restraurant_store OWNER TO postgres;

--
-- Name: restraurant_store_restraurant_store_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.restraurant_store_restraurant_store_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.restraurant_store_restraurant_store_item_id_seq OWNER TO postgres;

--
-- Name: restraurant_store_restraurant_store_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.restraurant_store_restraurant_store_item_id_seq OWNED BY public.restraurant_store.restraurant_store_item_id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_name character varying(255) NOT NULL,
    role_description text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    role_id bigint NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_role_id_seq OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- Name: sales_cashiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_cashiers (
    sales_cashier_id bigint NOT NULL,
    staff_id integer NOT NULL,
    balance numeric(15,2) NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    pin integer NOT NULL
);


ALTER TABLE public.sales_cashiers OWNER TO postgres;

--
-- Name: sales_cashiers_sales_cashier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_cashiers_sales_cashier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_cashiers_sales_cashier_id_seq OWNER TO postgres;

--
-- Name: sales_cashiers_sales_cashier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_cashiers_sales_cashier_id_seq OWNED BY public.sales_cashiers.sales_cashier_id;


--
-- Name: sales_order_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order_details (
    sales_order_details_id bigint NOT NULL,
    order_total numeric(15,2) NOT NULL,
    vat numeric(15,2) NOT NULL,
    cat numeric(15,2) NOT NULL,
    user_id integer NOT NULL,
    status character varying(200) DEFAULT 'Posted'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sales_order_details OWNER TO postgres;

--
-- Name: sales_order_details_sales_order_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_details_sales_order_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_order_details_sales_order_details_id_seq OWNER TO postgres;

--
-- Name: sales_order_details_sales_order_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_details_sales_order_details_id_seq OWNED BY public.sales_order_details.sales_order_details_id;


--
-- Name: sales_order_entry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order_entry (
    sales_order_entry_id bigint NOT NULL,
    order_total numeric(15,2) NOT NULL,
    sales_order_details_id integer NOT NULL,
    menu_item_id integer NOT NULL,
    quanity numeric(15,2) NOT NULL,
    price numeric(15,2) NOT NULL,
    total_value numeric(15,2) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sales_order_entry OWNER TO postgres;

--
-- Name: sales_order_entry_sales_order_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_entry_sales_order_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_order_entry_sales_order_entry_id_seq OWNER TO postgres;

--
-- Name: sales_order_entry_sales_order_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_entry_sales_order_entry_id_seq OWNED BY public.sales_order_entry.sales_order_entry_id;


--
-- Name: shift; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shift (
    shift_id bigint NOT NULL,
    shift_start timestamp with time zone NOT NULL,
    shift_end timestamp with time zone NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE public.shift OWNER TO postgres;

--
-- Name: shift_shift_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shift_shift_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shift_shift_id_seq OWNER TO postgres;

--
-- Name: shift_shift_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shift_shift_id_seq OWNED BY public.shift.shift_id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    staff_id bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    email character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer,
    payroll_category integer,
    is_active boolean DEFAULT true
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_staff_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_staff_id_seq OWNER TO postgres;

--
-- Name: staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_staff_id_seq OWNED BY public.staff.staff_id;


--
-- Name: station; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.station (
    station_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    name character varying(200) NOT NULL,
    lead_staff_id integer NOT NULL
);


ALTER TABLE public.station OWNER TO postgres;

--
-- Name: station_station_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.station_station_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.station_station_id_seq OWNER TO postgres;

--
-- Name: station_station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.station_station_id_seq OWNED BY public.station.station_id;


--
-- Name: stock_take_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_take_header (
    stock_take_header_id bigint NOT NULL,
    stock_take_date date,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stock_take_header OWNER TO postgres;

--
-- Name: stock_take_header_stock_take_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_take_header_stock_take_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_take_header_stock_take_header_id_seq OWNER TO postgres;

--
-- Name: stock_take_header_stock_take_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_take_header_stock_take_header_id_seq OWNED BY public.stock_take_header.stock_take_header_id;


--
-- Name: stock_take_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_take_line (
    stock_take_line_id bigint NOT NULL,
    stock_take_header_id integer NOT NULL,
    item_id integer NOT NULL,
    physical_quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    system_quantity numeric(15,2) DEFAULT 0.00 NOT NULL,
    variance numeric(15,2) DEFAULT 0.00 NOT NULL,
    viance_reason text
);


ALTER TABLE public.stock_take_line OWNER TO postgres;

--
-- Name: stock_take_line_stock_take_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_take_line_stock_take_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_take_line_stock_take_line_id_seq OWNER TO postgres;

--
-- Name: stock_take_line_stock_take_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_take_line_stock_take_line_id_seq OWNED BY public.stock_take_line.stock_take_line_id;


--
-- Name: store_issue_header; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_issue_header (
    store_issue_header_id bigint NOT NULL,
    issue_date date NOT NULL,
    description text NOT NULL,
    issued_by integer NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.store_issue_header OWNER TO postgres;

--
-- Name: store_issue_header_store_issue_header_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_issue_header_store_issue_header_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_issue_header_store_issue_header_id_seq OWNER TO postgres;

--
-- Name: store_issue_header_store_issue_header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_issue_header_store_issue_header_id_seq OWNED BY public.store_issue_header.store_issue_header_id;


--
-- Name: store_issue_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_issue_line (
    store_issue_line_id bigint NOT NULL,
    store_item_id integer NOT NULL,
    issue_quantity numeric(15,2) NOT NULL,
    initial_value numeric(15,2) NOT NULL,
    final_value numeric(15,2) NOT NULL,
    store_issue_header_id integer NOT NULL
);


ALTER TABLE public.store_issue_line OWNER TO postgres;

--
-- Name: store_issue_line_store_issue_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_issue_line_store_issue_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_issue_line_store_issue_line_id_seq OWNER TO postgres;

--
-- Name: store_issue_line_store_issue_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_issue_line_store_issue_line_id_seq OWNED BY public.store_issue_line.store_issue_line_id;


--
-- Name: store_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_item (
    store_item_id bigint NOT NULL,
    store_id integer NOT NULL,
    item_id integer NOT NULL,
    quantity numeric(15,4) DEFAULT 0.00 NOT NULL,
    buying_price numeric(15,2) DEFAULT 0.00 NOT NULL,
    item_unit_id integer NOT NULL,
    item_category integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.store_item OWNER TO postgres;

--
-- Name: store_item_store_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_item_store_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_item_store_item_id_seq OWNER TO postgres;

--
-- Name: store_item_store_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_item_store_item_id_seq OWNED BY public.store_item.store_item_id;


--
-- Name: store_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_register (
    store_id bigint NOT NULL,
    store_name character varying(255) NOT NULL,
    created_at timestamp with time zone,
    location character varying(255)
);


ALTER TABLE public.store_register OWNER TO postgres;

--
-- Name: store_register_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_register_store_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_register_store_id_seq OWNER TO postgres;

--
-- Name: store_register_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_register_store_id_seq OWNED BY public.store_register.store_id;


--
-- Name: store_transfer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_transfer (
    store_transfer_id bigint NOT NULL,
    store_item_id integer NOT NULL,
    item_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    created_by integer,
    quantity numeric(15,2) NOT NULL,
    initial numeric(15,2) NOT NULL,
    final numeric(15,2) NOT NULL
);


ALTER TABLE public.store_transfer OWNER TO postgres;

--
-- Name: store_transfer_store_transfer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_transfer_store_transfer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_transfer_store_transfer_id_seq OWNER TO postgres;

--
-- Name: store_transfer_store_transfer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_transfer_store_transfer_id_seq OWNED BY public.store_transfer.store_transfer_id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    phone character varying(255) NOT NULL,
    balance numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    is_active boolean DEFAULT true,
    supplier_name character varying(200) NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suppliers_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suppliers_supplier_id_seq OWNER TO postgres;

--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suppliers_supplier_id_seq OWNED BY public.suppliers.supplier_id;


--
-- Name: test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test (
    item_id integer NOT NULL,
    quantity integer NOT NULL,
    store_item_id integer NOT NULL
);


ALTER TABLE public.test OWNER TO postgres;

--
-- Name: test_menu_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_menu_item (
    menu_register_id bigint NOT NULL
);


ALTER TABLE public.test_menu_item OWNER TO postgres;

--
-- Name: test_menu_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_menu_register (
    menu_register_id bigint NOT NULL
);


ALTER TABLE public.test_menu_register OWNER TO postgres;

--
-- Name: test_menu_register_menu_register_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_menu_register_menu_register_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.test_menu_register_menu_register_id_seq OWNER TO postgres;

--
-- Name: test_menu_register_menu_register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_menu_register_menu_register_id_seq OWNED BY public.test_menu_register.menu_register_id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_role_id bigint NOT NULL,
    role_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_user_role_id_seq OWNER TO postgres;

--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_user_role_id_seq OWNED BY public.user_roles.user_role_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255),
    ttl numeric(10,2) DEFAULT 120,
    phone character varying(200) NOT NULL,
    user_id bigint NOT NULL,
    first_name character varying(200) NOT NULL,
    last_name character varying(200) NOT NULL,
    is_active boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: vendor_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor_entries (
    vendor_entry_id bigint NOT NULL,
    vendor_id bigint NOT NULL,
    description text NOT NULL,
    credited numeric(15,2) NOT NULL,
    debited numeric(15,2) NOT NULL,
    balance numeric(15,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by character varying(255)
);


ALTER TABLE public.vendor_entries OWNER TO postgres;

--
-- Name: vendors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendors (
    vendor_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    balance numeric(15,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    is_active boolean DEFAULT true,
    vendor_id bigint NOT NULL
);


ALTER TABLE public.vendors OWNER TO postgres;

--
-- Name: vendors_vendor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vendors_vendor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendors_vendor_id_seq OWNER TO postgres;

--
-- Name: vendors_vendor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vendors_vendor_id_seq OWNED BY public.vendors.vendor_id;


--
-- Name: voided_bills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voided_bills (
    voided_bill_id bigint NOT NULL,
    sales_order_details_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.voided_bills OWNER TO postgres;

--
-- Name: voided_bills_voided_bill_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.voided_bills_voided_bill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.voided_bills_voided_bill_id_seq OWNER TO postgres;

--
-- Name: voided_bills_voided_bill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.voided_bills_voided_bill_id_seq OWNED BY public.voided_bills.voided_bill_id;


--
-- Name: waitstaff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.waitstaff_id_seq
    START WITH 100
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.waitstaff_id_seq OWNER TO postgres;

--
-- Name: waitstaff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.waitstaff (
    waitstaff_id bigint DEFAULT nextval('public.waitstaff_id_seq'::regclass) NOT NULL,
    balance numeric(15,2) DEFAULT 0.00,
    pin integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    staff_id integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by integer NOT NULL,
    CONSTRAINT waitstaff_pin_check CHECK (((pin >= 100) AND (pin <= 999)))
);


ALTER TABLE public.waitstaff OWNER TO postgres;

--
-- Name: accounts account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN account_id SET DEFAULT nextval('public.accounts_account_id_seq'::regclass);


--
-- Name: active_shift active_shfit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_shift ALTER COLUMN active_shfit_id SET DEFAULT nextval('public.active_shift_active_shfit_id_seq'::regclass);


--
-- Name: banks bank_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks ALTER COLUMN bank_id SET DEFAULT nextval('public.banks_bank_id_seq'::regclass);


--
-- Name: cancel_bills cancel_bill_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cancel_bills ALTER COLUMN cancel_bill_id SET DEFAULT nextval('public.cancel_bills_cancel_bill_id_seq'::regclass);


--
-- Name: cash_accounts cash_account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_accounts ALTER COLUMN cash_account_id SET DEFAULT nextval('public.cash_accounts_cash_account_id_seq'::regclass);


--
-- Name: clear_bills cancel_bill_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clear_bills ALTER COLUMN cancel_bill_id SET DEFAULT nextval('public.clear_bills_cancel_bill_id_seq'::regclass);


--
-- Name: food_processing_header food_processing_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header ALTER COLUMN food_processing_header_id SET DEFAULT nextval('public.food_processing_header_food_processing_header_id_seq'::regclass);


--
-- Name: food_processing_line food_processing_line_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line ALTER COLUMN food_processing_line_id SET DEFAULT nextval('public.food_processing_line_food_processing_line_id_seq'::regclass);


--
-- Name: fund_transfer fund_transfer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_transfer ALTER COLUMN fund_transfer_id SET DEFAULT nextval('public.fund_transfer_fund_transfer_id_seq'::regclass);


--
-- Name: gl_accounts gl_account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_accounts ALTER COLUMN gl_account_id SET DEFAULT nextval('public.gl_accounts_gl_account_id_seq'::regclass);


--
-- Name: hot_kichen_store_tracking hot_kichen_store_tracking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hot_kichen_store_tracking ALTER COLUMN hot_kichen_store_tracking_id SET DEFAULT nextval('public.hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq'::regclass);


--
-- Name: hot_kitchen_tracking hot_kitchen_tracking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hot_kitchen_tracking ALTER COLUMN hot_kitchen_tracking_id SET DEFAULT nextval('public.hot_kitchen_tracking_hot_kitchen_tracking_id_seq'::regclass);


--
-- Name: item_category category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_category ALTER COLUMN category_id SET DEFAULT nextval('public.item_category_category_id_seq'::regclass);


--
-- Name: item_register item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register ALTER COLUMN item_id SET DEFAULT nextval('public.item_register_item_id_seq'::regclass);


--
-- Name: item_tracking item_tracking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking ALTER COLUMN item_tracking_id SET DEFAULT nextval('public.item_tracking_item_tracking_id_seq'::regclass);


--
-- Name: item_unit unit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_unit ALTER COLUMN unit_id SET DEFAULT nextval('public.item_unit_unit_id_seq'::regclass);


--
-- Name: kitchen_ingredients ingredient_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients ALTER COLUMN ingredient_id SET DEFAULT nextval('public.kitchen_ingredients_ingredient_id_seq'::regclass);


--
-- Name: kitchen_setup kitchen_setup_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup ALTER COLUMN kitchen_setup_id SET DEFAULT nextval('public.kitchen_setup_kitchen_setup_id_seq'::regclass);


--
-- Name: kitchen_setup_header kitchen_setup_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header ALTER COLUMN kitchen_setup_header_id SET DEFAULT nextval('public.kitchen_setup_header_kitchen_setup_header_id_seq'::regclass);


--
-- Name: kitchen_store kitchen_store_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_store ALTER COLUMN kitchen_store_item_id SET DEFAULT nextval('public.hot_kitchen_store_hot_kitchen_store_id_seq'::regclass);


--
-- Name: menu_category menu_category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category ALTER COLUMN menu_category_id SET DEFAULT nextval('public.menu_category_menu_category_id_seq'::regclass);


--
-- Name: menu_item menu_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item ALTER COLUMN menu_item_id SET DEFAULT nextval('public.menu_item_menu_item_id_seq'::regclass);


--
-- Name: menu_register menu_register_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register ALTER COLUMN menu_register_id SET DEFAULT nextval('public.menu_register_menu_register_id_seq'::regclass);


--
-- Name: menu_tracking menu_tracking_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_tracking ALTER COLUMN menu_tracking_id SET DEFAULT nextval('public.menu_tracking_menu_tracking_id_seq'::regclass);


--
-- Name: menu_unit menu_unit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_unit ALTER COLUMN menu_unit_id SET DEFAULT nextval('public.menu_unit_menu_unit_id_seq'::regclass);


--
-- Name: menu_units menu_unit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_units ALTER COLUMN menu_unit_id SET DEFAULT nextval('public.menu_units_menu_unit_id_seq'::regclass);


--
-- Name: mpesa_till mpesa_till_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till ALTER COLUMN mpesa_till_id SET DEFAULT nextval('public.mpesa_till_mpesa_till_id_seq'::regclass);


--
-- Name: purchase_order purchase_order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order ALTER COLUMN purchase_order_id SET DEFAULT nextval('public.purchase_order_purchase_order_id_seq'::regclass);


--
-- Name: purchase_requisition purchase_requisition_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_requisition ALTER COLUMN purchase_requisition_id SET DEFAULT nextval('public.purchase_requisition_purchase_requisition_id_seq'::regclass);


--
-- Name: restraurant_store restraurant_store_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restraurant_store ALTER COLUMN restraurant_store_item_id SET DEFAULT nextval('public.restraurant_store_restraurant_store_item_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: sales_cashiers sales_cashier_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_cashiers ALTER COLUMN sales_cashier_id SET DEFAULT nextval('public.sales_cashiers_sales_cashier_id_seq'::regclass);


--
-- Name: sales_order_details sales_order_details_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_details ALTER COLUMN sales_order_details_id SET DEFAULT nextval('public.sales_order_details_sales_order_details_id_seq'::regclass);


--
-- Name: sales_order_entry sales_order_entry_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_entry ALTER COLUMN sales_order_entry_id SET DEFAULT nextval('public.sales_order_entry_sales_order_entry_id_seq'::regclass);


--
-- Name: shift shift_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift ALTER COLUMN shift_id SET DEFAULT nextval('public.shift_shift_id_seq'::regclass);


--
-- Name: staff staff_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN staff_id SET DEFAULT nextval('public.staff_staff_id_seq'::regclass);


--
-- Name: station station_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station ALTER COLUMN station_id SET DEFAULT nextval('public.station_station_id_seq'::regclass);


--
-- Name: stock_take_header stock_take_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_header ALTER COLUMN stock_take_header_id SET DEFAULT nextval('public.stock_take_header_stock_take_header_id_seq'::regclass);


--
-- Name: stock_take_line stock_take_line_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line ALTER COLUMN stock_take_line_id SET DEFAULT nextval('public.stock_take_line_stock_take_line_id_seq'::regclass);


--
-- Name: store_issue_header store_issue_header_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_header ALTER COLUMN store_issue_header_id SET DEFAULT nextval('public.store_issue_header_store_issue_header_id_seq'::regclass);


--
-- Name: store_issue_line store_issue_line_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_line ALTER COLUMN store_issue_line_id SET DEFAULT nextval('public.store_issue_line_store_issue_line_id_seq'::regclass);


--
-- Name: store_item store_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item ALTER COLUMN store_item_id SET DEFAULT nextval('public.store_item_store_item_id_seq'::regclass);


--
-- Name: store_register store_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_register ALTER COLUMN store_id SET DEFAULT nextval('public.store_register_store_id_seq'::regclass);


--
-- Name: store_transfer store_transfer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_transfer ALTER COLUMN store_transfer_id SET DEFAULT nextval('public.store_transfer_store_transfer_id_seq'::regclass);


--
-- Name: suppliers supplier_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplier_id SET DEFAULT nextval('public.suppliers_supplier_id_seq'::regclass);


--
-- Name: test_menu_register menu_register_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_menu_register ALTER COLUMN menu_register_id SET DEFAULT nextval('public.test_menu_register_menu_register_id_seq'::regclass);


--
-- Name: user_roles user_role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN user_role_id SET DEFAULT nextval('public.user_roles_user_role_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: vendors vendor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors ALTER COLUMN vendor_id SET DEFAULT nextval('public.vendors_vendor_id_seq'::regclass);


--
-- Name: voided_bills voided_bill_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voided_bills ALTER COLUMN voided_bill_id SET DEFAULT nextval('public.voided_bills_voided_bill_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (account_id, account_name, balance, created_by, created_at, gl_account_id) FROM stdin;
\.
COPY public.accounts (account_id, account_name, balance, created_by, created_at, gl_account_id) FROM '$$PATH$$/3935.dat';

--
-- Data for Name: active_shift; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.active_shift (active_shfit_id, start_time, end_time) FROM stdin;
\.
COPY public.active_shift (active_shfit_id, start_time, end_time) FROM '$$PATH$$/4008.dat';

--
-- Data for Name: banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banks (bank_id, bank_name, balance, created_by, created_at, bank_number) FROM stdin;
\.
COPY public.banks (bank_id, bank_name, balance, created_by, created_at, bank_number) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: cancel_bills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cancel_bills (cancel_bill_id, sales_order_details_id, user_id, created_at) FROM stdin;
\.
COPY public.cancel_bills (cancel_bill_id, sales_order_details_id, user_id, created_at) FROM '$$PATH$$/4000.dat';

--
-- Data for Name: cash_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cash_accounts (cash_account_id, cash_account_name, balance, created_by, created_at) FROM stdin;
\.
COPY public.cash_accounts (cash_account_id, cash_account_name, balance, created_by, created_at) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: clear_bills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clear_bills (cancel_bill_id, sales_order_details_id, clear_type, amount, balance, user_id, created_at) FROM stdin;
\.
COPY public.clear_bills (cancel_bill_id, sales_order_details_id, clear_type, amount, balance, user_id, created_at) FROM '$$PATH$$/4002.dat';

--
-- Data for Name: food_processing_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_processing_header (food_processing_header_id, name, shift_id, created_by) FROM stdin;
\.
COPY public.food_processing_header (food_processing_header_id, name, shift_id, created_by) FROM '$$PATH$$/3961.dat';

--
-- Data for Name: food_processing_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_processing_line (food_processing_line_id, food_processing_header_id, name, station_id, kitchen_setup_id, created_at, created_by) FROM stdin;
\.
COPY public.food_processing_line (food_processing_line_id, food_processing_header_id, name, station_id, kitchen_setup_id, created_at, created_by) FROM '$$PATH$$/3967.dat';

--
-- Data for Name: fund_transfer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fund_transfer (fund_transfer_id, src_account_name, des_account_name, src_account_balance, des_account_balance, amount, created_at, src_accound_id, des_accound_id) FROM stdin;
\.
COPY public.fund_transfer (fund_transfer_id, src_account_name, des_account_name, src_account_balance, des_account_balance, amount, created_at, src_accound_id, des_accound_id) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: gl_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_accounts (gl_account_id, gl_account_name, balance, created_by, created_at) FROM stdin;
\.
COPY public.gl_accounts (gl_account_id, gl_account_name, balance, created_by, created_at) FROM '$$PATH$$/3937.dat';

--
-- Data for Name: hot_kichen_store_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hot_kichen_store_tracking (hot_kichen_store_tracking_id, item_id, intial_value, final_value, reason, created_by) FROM stdin;
\.
COPY public.hot_kichen_store_tracking (hot_kichen_store_tracking_id, item_id, intial_value, final_value, reason, created_by) FROM '$$PATH$$/4014.dat';

--
-- Data for Name: hot_kitchen_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hot_kitchen_tracking (hot_kitchen_tracking_id, current_quantity, new_quantity, reason, action_by, store_item_id) FROM stdin;
\.
COPY public.hot_kitchen_tracking (hot_kitchen_tracking_id, current_quantity, new_quantity, reason, action_by, store_item_id) FROM '$$PATH$$/4018.dat';

--
-- Data for Name: item_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_category (category_id, category_name, category_description, created_at) FROM stdin;
\.
COPY public.item_category (category_id, category_name, category_description, created_at) FROM '$$PATH$$/3953.dat';

--
-- Data for Name: item_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_register (item_id, item_name, item_description, item_status, created_by, created_at) FROM stdin;
\.
COPY public.item_register (item_id, item_name, item_description, item_status, created_by, created_at) FROM '$$PATH$$/3947.dat';

--
-- Data for Name: item_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_tracking (item_tracking_id, store_item_id, current_quantity, new_quantity, reason, action_by) FROM stdin;
\.
COPY public.item_tracking (item_tracking_id, store_item_id, current_quantity, new_quantity, reason, action_by) FROM '$$PATH$$/3990.dat';

--
-- Data for Name: item_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_unit (unit_id, standard_unit_name, standard_unit_value, other_unit_name, other_unit_value, created_at) FROM stdin;
\.
COPY public.item_unit (unit_id, standard_unit_name, standard_unit_value, other_unit_name, other_unit_value, created_at) FROM '$$PATH$$/3949.dat';

--
-- Data for Name: kitchen_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_ingredients (ingredient_id, ingredients_id, quantity, store_item_id, source_type) FROM stdin;
\.
COPY public.kitchen_ingredients (ingredient_id, ingredients_id, quantity, store_item_id, source_type) FROM '$$PATH$$/3988.dat';

--
-- Data for Name: kitchen_setup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_setup (kitchen_setup_id, name, station_id, created_at, menu_item_id) FROM stdin;
\.
COPY public.kitchen_setup (kitchen_setup_id, name, station_id, created_at, menu_item_id) FROM '$$PATH$$/3965.dat';

--
-- Data for Name: kitchen_setup_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_setup_header (kitchen_setup_header_id, menu_register_id, quanity, menu_unit_id) FROM stdin;
\.
COPY public.kitchen_setup_header (kitchen_setup_header_id, menu_register_id, quanity, menu_unit_id) FROM '$$PATH$$/3980.dat';

--
-- Data for Name: kitchen_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kitchen_store (kitchen_store_item_id, quantity, updated_at, item_id, store_item_id, selling_price, created_at, store_id) FROM stdin;
\.
COPY public.kitchen_store (kitchen_store_item_id, quantity, updated_at, item_id, store_item_id, selling_price, created_at, store_id) FROM '$$PATH$$/4012.dat';

--
-- Data for Name: menu_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_category (menu_category_id, description, category_name, category_abbr, created_at) FROM stdin;
\.
COPY public.menu_category (menu_category_id, description, category_name, category_abbr, created_at) FROM '$$PATH$$/3974.dat';

--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_item (menu_item_id, menu_register_id, quantity, price, menu_category_id, created_at, available) FROM stdin;
\.
COPY public.menu_item (menu_item_id, menu_register_id, quantity, price, menu_category_id, created_at, available) FROM '$$PATH$$/3976.dat';

--
-- Data for Name: menu_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_register (menu_register_id, name, description, active, created_at, created_by) FROM stdin;
\.
COPY public.menu_register (menu_register_id, name, description, active, created_at, created_by) FROM '$$PATH$$/3972.dat';

--
-- Data for Name: menu_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_tracking (menu_tracking_id, menu_item_id, current_quantity, new_quantity, reason, action_by) FROM stdin;
\.
COPY public.menu_tracking (menu_tracking_id, menu_item_id, current_quantity, new_quantity, reason, action_by) FROM '$$PATH$$/3992.dat';

--
-- Data for Name: menu_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_unit (menu_unit_id, unit_name, unit_abbr, value, created_at) FROM stdin;
\.
COPY public.menu_unit (menu_unit_id, unit_name, unit_abbr, value, created_at) FROM '$$PATH$$/3986.dat';

--
-- Data for Name: menu_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_units (menu_unit_id, value, abbreaviation) FROM stdin;
\.
COPY public.menu_units (menu_unit_id, value, abbreaviation) FROM '$$PATH$$/3978.dat';

--
-- Data for Name: mpesa_till; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mpesa_till (mpesa_till_id, mpesa_till_name, balance, created_by, till_number, created_at) FROM stdin;
\.
COPY public.mpesa_till (mpesa_till_id, mpesa_till_name, balance, created_by, till_number, created_at) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: purchase_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_order (purchase_order_id, purchase_order_total, purchase_order_type, vat_total, pay_type, created_at, created_by) FROM stdin;
\.
COPY public.purchase_order (purchase_order_id, purchase_order_total, purchase_order_type, vat_total, pay_type, created_at, created_by) FROM '$$PATH$$/4004.dat';

--
-- Data for Name: purchase_requisition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_requisition (purchase_requisition_id, purchase_requisition_total, purchase_requisition_type, vat_total, pay_type, created_at, created_by) FROM stdin;
\.
COPY public.purchase_requisition (purchase_requisition_id, purchase_requisition_total, purchase_requisition_type, vat_total, pay_type, created_at, created_by) FROM '$$PATH$$/4006.dat';

--
-- Data for Name: restraurant_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restraurant_store (restraurant_store_item_id, quantity, created_at, item_id, store_item_id, selling_price) FROM stdin;
\.
COPY public.restraurant_store (restraurant_store_item_id, quantity, created_at, item_id, store_item_id, selling_price) FROM '$$PATH$$/4021.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_name, role_description, created_at, role_id, created_by) FROM stdin;
\.
COPY public.roles (role_name, role_description, created_at, role_id, created_by) FROM '$$PATH$$/3917.dat';

--
-- Data for Name: sales_cashiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_cashiers (sales_cashier_id, staff_id, balance, created_by, created_at, pin) FROM stdin;
\.
COPY public.sales_cashiers (sales_cashier_id, staff_id, balance, created_by, created_at, pin) FROM '$$PATH$$/4010.dat';

--
-- Data for Name: sales_order_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order_details (sales_order_details_id, order_total, vat, cat, user_id, status, created_at) FROM stdin;
\.
COPY public.sales_order_details (sales_order_details_id, order_total, vat, cat, user_id, status, created_at) FROM '$$PATH$$/3994.dat';

--
-- Data for Name: sales_order_entry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order_entry (sales_order_entry_id, order_total, sales_order_details_id, menu_item_id, quanity, price, total_value, user_id, created_at) FROM stdin;
\.
COPY public.sales_order_entry (sales_order_entry_id, order_total, sales_order_details_id, menu_item_id, quanity, price, total_value, user_id, created_at) FROM '$$PATH$$/3996.dat';

--
-- Data for Name: shift; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shift (shift_id, shift_start, shift_end, created_by) FROM stdin;
\.
COPY public.shift (shift_id, shift_start, shift_end, created_by) FROM '$$PATH$$/3932.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (staff_id, first_name, last_name, phone, email, created_at, created_by, payroll_category, is_active) FROM stdin;
\.
COPY public.staff (staff_id, first_name, last_name, phone, email, created_at, created_by, payroll_category, is_active) FROM '$$PATH$$/3924.dat';

--
-- Data for Name: station; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.station (station_id, created_at, name, lead_staff_id) FROM stdin;
\.
COPY public.station (station_id, created_at, name, lead_staff_id) FROM '$$PATH$$/3963.dat';

--
-- Data for Name: stock_take_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_take_header (stock_take_header_id, stock_take_date, created_by, created_at) FROM stdin;
\.
COPY public.stock_take_header (stock_take_header_id, stock_take_date, created_by, created_at) FROM '$$PATH$$/3957.dat';

--
-- Data for Name: stock_take_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_take_line (stock_take_line_id, stock_take_header_id, item_id, physical_quantity, system_quantity, variance, viance_reason) FROM stdin;
\.
COPY public.stock_take_line (stock_take_line_id, stock_take_header_id, item_id, physical_quantity, system_quantity, variance, viance_reason) FROM '$$PATH$$/3959.dat';

--
-- Data for Name: store_issue_header; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_issue_header (store_issue_header_id, issue_date, description, issued_by, created_by, created_at) FROM stdin;
\.
COPY public.store_issue_header (store_issue_header_id, issue_date, description, issued_by, created_by, created_at) FROM '$$PATH$$/3982.dat';

--
-- Data for Name: store_issue_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_issue_line (store_issue_line_id, store_item_id, issue_quantity, initial_value, final_value, store_issue_header_id) FROM stdin;
\.
COPY public.store_issue_line (store_issue_line_id, store_item_id, issue_quantity, initial_value, final_value, store_issue_header_id) FROM '$$PATH$$/3984.dat';

--
-- Data for Name: store_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_item (store_item_id, store_id, item_id, quantity, buying_price, item_unit_id, item_category, created_at) FROM stdin;
\.
COPY public.store_item (store_item_id, store_id, item_id, quantity, buying_price, item_unit_id, item_category, created_at) FROM '$$PATH$$/3955.dat';

--
-- Data for Name: store_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_register (store_id, store_name, created_at, location) FROM stdin;
\.
COPY public.store_register (store_id, store_name, created_at, location) FROM '$$PATH$$/3951.dat';

--
-- Data for Name: store_transfer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_transfer (store_transfer_id, store_item_id, item_id, created_at, created_by, quantity, initial, final) FROM stdin;
\.
COPY public.store_transfer (store_transfer_id, store_item_id, item_id, created_at, created_by, quantity, initial, final) FROM '$$PATH$$/4016.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (phone, balance, created_at, created_by, is_active, supplier_name, supplier_id) FROM stdin;
\.
COPY public.suppliers (phone, balance, created_at, created_by, is_active, supplier_name, supplier_id) FROM '$$PATH$$/3925.dat';

--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test (item_id, quantity, store_item_id) FROM stdin;
\.
COPY public.test (item_id, quantity, store_item_id) FROM '$$PATH$$/4019.dat';

--
-- Data for Name: test_menu_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_menu_item (menu_register_id) FROM stdin;
\.
COPY public.test_menu_item (menu_register_id) FROM '$$PATH$$/3970.dat';

--
-- Data for Name: test_menu_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_menu_register (menu_register_id) FROM stdin;
\.
COPY public.test_menu_register (menu_register_id) FROM '$$PATH$$/3969.dat';

--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_role_id, role_id, user_id, created_at) FROM stdin;
\.
COPY public.user_roles (user_role_id, role_id, user_id, created_at) FROM '$$PATH$$/3928.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, password, created_at, created_by, ttl, phone, user_id, first_name, last_name, is_active) FROM stdin;
\.
COPY public.users (username, password, created_at, created_by, ttl, phone, user_id, first_name, last_name, is_active) FROM '$$PATH$$/3921.dat';

--
-- Data for Name: vendor_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor_entries (vendor_entry_id, vendor_id, description, credited, debited, balance, created_at, created_by) FROM stdin;
\.
COPY public.vendor_entries (vendor_entry_id, vendor_id, description, credited, debited, balance, created_at, created_by) FROM '$$PATH$$/3920.dat';

--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendors (vendor_name, phone, balance, created_at, created_by, is_active, vendor_id) FROM stdin;
\.
COPY public.vendors (vendor_name, phone, balance, created_at, created_by, is_active, vendor_id) FROM '$$PATH$$/3926.dat';

--
-- Data for Name: voided_bills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voided_bills (voided_bill_id, sales_order_details_id, user_id, created_at) FROM stdin;
\.
COPY public.voided_bills (voided_bill_id, sales_order_details_id, user_id, created_at) FROM '$$PATH$$/3998.dat';

--
-- Data for Name: waitstaff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.waitstaff (waitstaff_id, balance, pin, created_at, staff_id, is_active, created_by) FROM stdin;
\.
COPY public.waitstaff (waitstaff_id, balance, pin, created_at, staff_id, is_active, created_by) FROM '$$PATH$$/3919.dat';

--
-- Name: accounts_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_account_id_seq', 8, true);


--
-- Name: active_shift_active_shfit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.active_shift_active_shfit_id_seq', 1, false);


--
-- Name: banks_bank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banks_bank_id_seq', 2, true);


--
-- Name: cancel_bills_cancel_bill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cancel_bills_cancel_bill_id_seq', 1, false);


--
-- Name: cash_accounts_cash_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cash_accounts_cash_account_id_seq', 2, true);


--
-- Name: clear_bills_cancel_bill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clear_bills_cancel_bill_id_seq', 1, false);


--
-- Name: custom_id_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_id_sequence', 2, true);


--
-- Name: food_processing_header_food_processing_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.food_processing_header_food_processing_header_id_seq', 1, false);


--
-- Name: food_processing_line_food_processing_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.food_processing_line_food_processing_line_id_seq', 1, false);


--
-- Name: fund_transfer_fund_transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fund_transfer_fund_transfer_id_seq', 1, false);


--
-- Name: gl_accounts_gl_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gl_accounts_gl_account_id_seq', 2, true);


--
-- Name: hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hot_kichen_store_tracking_hot_kichen_store_tracking_id_seq', 1, false);


--
-- Name: hot_kitchen_store_hot_kitchen_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hot_kitchen_store_hot_kitchen_store_id_seq', 14, true);


--
-- Name: hot_kitchen_tracking_hot_kitchen_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hot_kitchen_tracking_hot_kitchen_tracking_id_seq', 28, true);


--
-- Name: item_category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_category_category_id_seq', 8, true);


--
-- Name: item_register_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_register_item_id_seq', 95, true);


--
-- Name: item_tracking_item_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_tracking_item_tracking_id_seq', 86, true);


--
-- Name: item_unit_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_unit_unit_id_seq', 7, true);


--
-- Name: kitchen_ingredients_ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitchen_ingredients_ingredient_id_seq', 40, true);


--
-- Name: kitchen_setup_header_kitchen_setup_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitchen_setup_header_kitchen_setup_header_id_seq', 1, false);


--
-- Name: kitchen_setup_kitchen_setup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kitchen_setup_kitchen_setup_id_seq', 71, true);


--
-- Name: menu_category_menu_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_category_menu_category_id_seq', 25, true);


--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_item_menu_item_id_seq', 54, true);


--
-- Name: menu_register_menu_register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_register_menu_register_id_seq', 128, true);


--
-- Name: menu_tracking_menu_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_tracking_menu_tracking_id_seq', 64, true);


--
-- Name: menu_unit_menu_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_unit_menu_unit_id_seq', 7, true);


--
-- Name: menu_units_menu_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_units_menu_unit_id_seq', 1, false);


--
-- Name: mpesa_till_mpesa_till_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mpesa_till_mpesa_till_id_seq', 5, true);


--
-- Name: purchase_order_purchase_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_order_purchase_order_id_seq', 1, false);


--
-- Name: purchase_requisition_purchase_requisition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_requisition_purchase_requisition_id_seq', 1, false);


--
-- Name: restraurant_store_restraurant_store_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.restraurant_store_restraurant_store_item_id_seq', 1, false);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 25, true);


--
-- Name: sales_cashiers_sales_cashier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_cashiers_sales_cashier_id_seq', 2, true);


--
-- Name: sales_order_details_sales_order_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_details_sales_order_details_id_seq', 1, false);


--
-- Name: sales_order_entry_sales_order_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_entry_sales_order_entry_id_seq', 1, false);


--
-- Name: shift_shift_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shift_shift_id_seq', 4, true);


--
-- Name: staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_staff_id_seq', 5, true);


--
-- Name: station_station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.station_station_id_seq', 5, true);


--
-- Name: stock_take_header_stock_take_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_take_header_stock_take_header_id_seq', 1, false);


--
-- Name: stock_take_line_stock_take_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_take_line_stock_take_line_id_seq', 1, false);


--
-- Name: store_issue_header_store_issue_header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_issue_header_store_issue_header_id_seq', 27, true);


--
-- Name: store_issue_line_store_issue_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_issue_line_store_issue_line_id_seq', 19, true);


--
-- Name: store_item_store_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_item_store_item_id_seq', 40, true);


--
-- Name: store_register_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_register_store_id_seq', 3, true);


--
-- Name: store_transfer_store_transfer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_transfer_store_transfer_id_seq', 1, false);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_supplier_id_seq', 10, true);


--
-- Name: test_menu_register_menu_register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_menu_register_menu_register_id_seq', 1, false);


--
-- Name: user_roles_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_user_role_id_seq', 80, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 39, true);


--
-- Name: vendors_vendor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vendors_vendor_id_seq', 18, true);


--
-- Name: voided_bills_voided_bill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.voided_bills_voided_bill_id_seq', 1, false);


--
-- Name: waitstaff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.waitstaff_id_seq', 110, true);


--
-- Name: accounts accounts_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_name_key UNIQUE (account_name);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: active_shift active_shift_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.active_shift
    ADD CONSTRAINT active_shift_pkey PRIMARY KEY (active_shfit_id);


--
-- Name: banks banks_bank_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_bank_name_key UNIQUE (bank_name);


--
-- Name: banks banks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banks
    ADD CONSTRAINT banks_pkey PRIMARY KEY (bank_id);


--
-- Name: cancel_bills cancel_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cancel_bills
    ADD CONSTRAINT cancel_bills_pkey PRIMARY KEY (cancel_bill_id);


--
-- Name: cash_accounts cash_accounts_cash_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_cash_account_name_key UNIQUE (cash_account_name);


--
-- Name: cash_accounts cash_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cash_accounts
    ADD CONSTRAINT cash_accounts_pkey PRIMARY KEY (cash_account_id);


--
-- Name: clear_bills clear_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clear_bills
    ADD CONSTRAINT clear_bills_pkey PRIMARY KEY (cancel_bill_id);


--
-- Name: food_processing_header food_processing_header_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_name_key UNIQUE (name);


--
-- Name: food_processing_header food_processing_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_pkey PRIMARY KEY (food_processing_header_id);


--
-- Name: food_processing_line food_processing_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_pkey PRIMARY KEY (food_processing_line_id);


--
-- Name: fund_transfer fund_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_transfer
    ADD CONSTRAINT fund_transfer_pkey PRIMARY KEY (fund_transfer_id);


--
-- Name: gl_accounts gl_accounts_gl_account_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_accounts
    ADD CONSTRAINT gl_accounts_gl_account_name_key UNIQUE (gl_account_name);


--
-- Name: gl_accounts gl_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_accounts
    ADD CONSTRAINT gl_accounts_pkey PRIMARY KEY (gl_account_id);


--
-- Name: hot_kichen_store_tracking hot_kichen_store_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hot_kichen_store_tracking
    ADD CONSTRAINT hot_kichen_store_tracking_pkey PRIMARY KEY (hot_kichen_store_tracking_id);


--
-- Name: kitchen_store hot_kitchen_store_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_store
    ADD CONSTRAINT hot_kitchen_store_item_id_key UNIQUE (item_id);


--
-- Name: kitchen_store hot_kitchen_store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_store
    ADD CONSTRAINT hot_kitchen_store_pkey PRIMARY KEY (kitchen_store_item_id);


--
-- Name: kitchen_store hot_kitchen_store_store_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_store
    ADD CONSTRAINT hot_kitchen_store_store_item_id_key UNIQUE (store_item_id);


--
-- Name: hot_kitchen_tracking hot_kitchen_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hot_kitchen_tracking
    ADD CONSTRAINT hot_kitchen_tracking_pkey PRIMARY KEY (hot_kitchen_tracking_id);


--
-- Name: item_category item_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_category
    ADD CONSTRAINT item_category_pkey PRIMARY KEY (category_id);


--
-- Name: item_register item_register_item_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register
    ADD CONSTRAINT item_register_item_name_key UNIQUE (item_name);


--
-- Name: item_register item_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register
    ADD CONSTRAINT item_register_pkey PRIMARY KEY (item_id);


--
-- Name: item_tracking item_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking
    ADD CONSTRAINT item_tracking_pkey PRIMARY KEY (item_tracking_id);


--
-- Name: item_unit item_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_unit
    ADD CONSTRAINT item_unit_pkey PRIMARY KEY (unit_id);


--
-- Name: kitchen_ingredients kitchen_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients
    ADD CONSTRAINT kitchen_ingredients_pkey PRIMARY KEY (ingredient_id);


--
-- Name: kitchen_setup_header kitchen_setup_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header
    ADD CONSTRAINT kitchen_setup_header_pkey PRIMARY KEY (kitchen_setup_header_id);


--
-- Name: kitchen_setup kitchen_setup_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_name_key UNIQUE (name);


--
-- Name: kitchen_setup kitchen_setup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_pkey PRIMARY KEY (kitchen_setup_id);


--
-- Name: menu_category menu_category_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_category_name_key UNIQUE (category_name);


--
-- Name: menu_category menu_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_pkey PRIMARY KEY (menu_category_id);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (menu_item_id);


--
-- Name: menu_register menu_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register
    ADD CONSTRAINT menu_register_pkey PRIMARY KEY (menu_register_id);


--
-- Name: menu_tracking menu_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_tracking
    ADD CONSTRAINT menu_tracking_pkey PRIMARY KEY (menu_tracking_id);


--
-- Name: menu_unit menu_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_unit
    ADD CONSTRAINT menu_unit_pkey PRIMARY KEY (menu_unit_id);


--
-- Name: menu_units menu_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_units
    ADD CONSTRAINT menu_units_pkey PRIMARY KEY (menu_unit_id);


--
-- Name: mpesa_till mpesa_till_mpesa_till_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till
    ADD CONSTRAINT mpesa_till_mpesa_till_name_key UNIQUE (mpesa_till_name);


--
-- Name: mpesa_till mpesa_till_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till
    ADD CONSTRAINT mpesa_till_pkey PRIMARY KEY (mpesa_till_id);


--
-- Name: mpesa_till mpesa_till_till_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mpesa_till
    ADD CONSTRAINT mpesa_till_till_number_key UNIQUE (till_number);


--
-- Name: users phone_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT phone_unique UNIQUE (phone);


--
-- Name: purchase_order purchase_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT purchase_order_pkey PRIMARY KEY (purchase_order_id);


--
-- Name: purchase_requisition purchase_requisition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_requisition
    ADD CONSTRAINT purchase_requisition_pkey PRIMARY KEY (purchase_requisition_id);


--
-- Name: restraurant_store restraurant_store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restraurant_store
    ADD CONSTRAINT restraurant_store_pkey PRIMARY KEY (restraurant_store_item_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: sales_cashiers sales_cashiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_cashiers
    ADD CONSTRAINT sales_cashiers_pkey PRIMARY KEY (sales_cashier_id);


--
-- Name: sales_order_details sales_order_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_details
    ADD CONSTRAINT sales_order_details_pkey PRIMARY KEY (sales_order_details_id);


--
-- Name: sales_order_entry sales_order_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_entry
    ADD CONSTRAINT sales_order_entry_pkey PRIMARY KEY (sales_order_entry_id);


--
-- Name: shift shift_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shift
    ADD CONSTRAINT shift_pkey PRIMARY KEY (shift_id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staff_id);


--
-- Name: station station_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_name_key UNIQUE (name);


--
-- Name: station station_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_pkey PRIMARY KEY (station_id);


--
-- Name: stock_take_header stock_take_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_header
    ADD CONSTRAINT stock_take_header_pkey PRIMARY KEY (stock_take_header_id);


--
-- Name: stock_take_line stock_take_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line
    ADD CONSTRAINT stock_take_line_pkey PRIMARY KEY (stock_take_line_id);


--
-- Name: store_issue_header store_issue_header_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_header
    ADD CONSTRAINT store_issue_header_pkey PRIMARY KEY (store_issue_header_id);


--
-- Name: store_issue_line store_issue_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_line
    ADD CONSTRAINT store_issue_line_pkey PRIMARY KEY (store_issue_line_id);


--
-- Name: store_item store_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_pkey PRIMARY KEY (store_item_id);


--
-- Name: store_register store_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_register
    ADD CONSTRAINT store_register_pkey PRIMARY KEY (store_id);


--
-- Name: store_transfer store_transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_transfer
    ADD CONSTRAINT store_transfer_pkey PRIMARY KEY (store_transfer_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- Name: test_menu_register test_menu_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_menu_register
    ADD CONSTRAINT test_menu_register_pkey PRIMARY KEY (menu_register_id);


--
-- Name: item_category unique_category_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_category
    ADD CONSTRAINT unique_category_name UNIQUE (category_name);


--
-- Name: store_item unique_item_store; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT unique_item_store UNIQUE (item_id, store_id);


--
-- Name: menu_register unique_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register
    ADD CONSTRAINT unique_name UNIQUE (name);


--
-- Name: store_register unique_store_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_register
    ADD CONSTRAINT unique_store_name UNIQUE (store_name);


--
-- Name: menu_unit unique_unit_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_unit
    ADD CONSTRAINT unique_unit_name UNIQUE (unit_name);


--
-- Name: users unique_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT unique_username UNIQUE (username);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: vendor_entries vendor_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor_entries
    ADD CONSTRAINT vendor_entries_pkey PRIMARY KEY (vendor_entry_id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (vendor_id);


--
-- Name: voided_bills voided_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voided_bills
    ADD CONSTRAINT voided_bills_pkey PRIMARY KEY (voided_bill_id);


--
-- Name: waitstaff waitstaff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_pkey PRIMARY KEY (waitstaff_id);


--
-- Name: menu_item set_menu_availability; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_menu_availability BEFORE INSERT OR UPDATE ON public.menu_item FOR EACH ROW EXECUTE FUNCTION public.update_menu_availability();


--
-- Name: cancel_bills cancel_bills_sales_order_details_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cancel_bills
    ADD CONSTRAINT cancel_bills_sales_order_details_id_fkey FOREIGN KEY (sales_order_details_id) REFERENCES public.sales_order_details(sales_order_details_id);


--
-- Name: cancel_bills cancel_bills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cancel_bills
    ADD CONSTRAINT cancel_bills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: clear_bills clear_bills_sales_order_details_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clear_bills
    ADD CONSTRAINT clear_bills_sales_order_details_id_fkey FOREIGN KEY (sales_order_details_id) REFERENCES public.sales_order_details(sales_order_details_id);


--
-- Name: clear_bills clear_bills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clear_bills
    ADD CONSTRAINT clear_bills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: food_processing_header food_processing_header_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: food_processing_header food_processing_header_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_header
    ADD CONSTRAINT food_processing_header_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shift(shift_id);


--
-- Name: food_processing_line food_processing_line_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: food_processing_line food_processing_line_food_processing_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_food_processing_header_id_fkey FOREIGN KEY (food_processing_header_id) REFERENCES public.food_processing_header(food_processing_header_id);


--
-- Name: food_processing_line food_processing_line_kitchen_setup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_kitchen_setup_id_fkey FOREIGN KEY (kitchen_setup_id) REFERENCES public.kitchen_setup(kitchen_setup_id);


--
-- Name: food_processing_line food_processing_line_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_processing_line
    ADD CONSTRAINT food_processing_line_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.station(station_id);


--
-- Name: hot_kichen_store_tracking hot_kichen_store_tracking_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hot_kichen_store_tracking
    ADD CONSTRAINT hot_kichen_store_tracking_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: kitchen_store hot_kitchen_store_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_store
    ADD CONSTRAINT hot_kitchen_store_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: hot_kitchen_tracking hot_kitchen_tracking_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hot_kitchen_tracking
    ADD CONSTRAINT hot_kitchen_tracking_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.kitchen_store(store_item_id);


--
-- Name: item_register item_register_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_register
    ADD CONSTRAINT item_register_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: item_tracking item_tracking_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_tracking
    ADD CONSTRAINT item_tracking_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: kitchen_ingredients kitchen_ingredients_ingredients_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_ingredients
    ADD CONSTRAINT kitchen_ingredients_ingredients_id_fkey FOREIGN KEY (ingredients_id) REFERENCES public.kitchen_setup(kitchen_setup_id);


--
-- Name: kitchen_setup_header kitchen_setup_header_menu_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header
    ADD CONSTRAINT kitchen_setup_header_menu_register_id_fkey FOREIGN KEY (menu_register_id) REFERENCES public.menu_register(menu_register_id);


--
-- Name: kitchen_setup_header kitchen_setup_header_menu_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup_header
    ADD CONSTRAINT kitchen_setup_header_menu_unit_id_fkey FOREIGN KEY (menu_unit_id) REFERENCES public.menu_units(menu_unit_id);


--
-- Name: kitchen_setup kitchen_setup_menu_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_menu_item_id_fkey FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id);


--
-- Name: kitchen_setup kitchen_setup_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_setup
    ADD CONSTRAINT kitchen_setup_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.station(station_id);


--
-- Name: kitchen_store kitchen_store_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kitchen_store
    ADD CONSTRAINT kitchen_store_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store_register(store_id);


--
-- Name: menu_item menu_item_menu_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_menu_category_id_fkey FOREIGN KEY (menu_category_id) REFERENCES public.menu_category(menu_category_id);


--
-- Name: menu_item menu_item_menu_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_menu_register_id_fkey FOREIGN KEY (menu_register_id) REFERENCES public.menu_register(menu_register_id);


--
-- Name: menu_register menu_register_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_register
    ADD CONSTRAINT menu_register_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: purchase_order purchase_order_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT purchase_order_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: purchase_requisition purchase_requisition_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_requisition
    ADD CONSTRAINT purchase_requisition_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: restraurant_store restraurant_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restraurant_store
    ADD CONSTRAINT restraurant_store_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: restraurant_store restraurant_store_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restraurant_store
    ADD CONSTRAINT restraurant_store_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: sales_cashiers sales_cashiers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_cashiers
    ADD CONSTRAINT sales_cashiers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: sales_cashiers sales_cashiers_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_cashiers
    ADD CONSTRAINT sales_cashiers_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- Name: sales_order_entry sales_order_entry_menu_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_entry
    ADD CONSTRAINT sales_order_entry_menu_item_id_fkey FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id);


--
-- Name: sales_order_entry sales_order_entry_sales_order_details_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order_entry
    ADD CONSTRAINT sales_order_entry_sales_order_details_id_fkey FOREIGN KEY (sales_order_details_id) REFERENCES public.sales_order_details(sales_order_details_id);


--
-- Name: station station_lead_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_lead_staff_id_fkey FOREIGN KEY (lead_staff_id) REFERENCES public.staff(staff_id);


--
-- Name: stock_take_header stock_take_header_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_header
    ADD CONSTRAINT stock_take_header_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: stock_take_line stock_take_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line
    ADD CONSTRAINT stock_take_line_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: stock_take_line stock_take_line_stock_take_header_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_take_line
    ADD CONSTRAINT stock_take_line_stock_take_header_id_fkey FOREIGN KEY (stock_take_header_id) REFERENCES public.stock_take_header(stock_take_header_id);


--
-- Name: store_issue_line store_issue_line_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_issue_line
    ADD CONSTRAINT store_issue_line_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: store_item store_item_item_category_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_item_category_fkey FOREIGN KEY (item_category) REFERENCES public.item_category(category_id);


--
-- Name: store_item store_item_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: store_item store_item_item_unit_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_item_unit_fkey FOREIGN KEY (item_unit_id) REFERENCES public.item_unit(unit_id);


--
-- Name: store_item store_item_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_item
    ADD CONSTRAINT store_item_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.store_register(store_id);


--
-- Name: store_transfer store_transfer_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_transfer
    ADD CONSTRAINT store_transfer_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item_register(item_id);


--
-- Name: store_transfer store_transfer_store_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_transfer
    ADD CONSTRAINT store_transfer_store_item_id_fkey FOREIGN KEY (store_item_id) REFERENCES public.store_item(store_item_id);


--
-- Name: test_menu_item test_menu_item_menu_register_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_menu_item
    ADD CONSTRAINT test_menu_item_menu_register_id_fkey FOREIGN KEY (menu_register_id) REFERENCES public.test_menu_register(menu_register_id);


--
-- Name: voided_bills voided_bills_sales_order_details_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voided_bills
    ADD CONSTRAINT voided_bills_sales_order_details_id_fkey FOREIGN KEY (sales_order_details_id) REFERENCES public.sales_order_details(sales_order_details_id);


--
-- Name: voided_bills voided_bills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voided_bills
    ADD CONSTRAINT voided_bills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: waitstaff waitstaff_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: waitstaff waitstaff_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.waitstaff
    ADD CONSTRAINT waitstaff_staff_id_fkey FOREIGN KEY (staff_id) REFERENCES public.staff(staff_id);


--
-- PostgreSQL database dump complete
--

